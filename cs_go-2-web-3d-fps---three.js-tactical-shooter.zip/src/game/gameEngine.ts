import * as THREE from 'three';
import { audio } from './audio';
import { BotState, checkCollision, hasLineOfSight, initBots, Team } from './botAI';
import { BoundingBox2D, buildMap, MapData } from './mapBuilder';
import { createC4BombModel, createPistolModel, createRifleModel, WeaponRig } from './weaponModels';

export interface KillfeedEntry {
  id: string;
  killer: string;
  killerTeam: Team;
  victim: string;
  victimTeam: Team;
  weapon: string;
  headshot: boolean;
  time: number;
}

export interface PlayerScoreData {
  id: string;
  name: string;
  team: Team;
  kills: number;
  deaths: number;
  score: number;
  ping: number;
  isAlive: boolean;
  isPlayer: boolean;
}

export type GameMode = 'defusal' | 'tdm';

export interface BombState {
  status: 'carried' | 'dropped' | 'planting' | 'planted' | 'defusing' | 'exploded' | 'defused';
  carrierName?: string;
  site?: 'A' | 'B';
  timer: number; // 40 seconds countdown
  position?: THREE.Vector3;
}

export interface HUDState {
  hp: number;
  armor: number;
  ammo: number;
  reserveAmmo: number;
  weaponName: string;
  isReloading: boolean;
  isAiming: boolean;
  team: Team;
  scoreT: number;
  scoreCT: number;
  roundTimer: number;
  gameMode: GameMode;
  mapName: string;
  bombState: BombState;
  interactPrompt: string | null;
  interactProgress: number; // 0 to 1
  hitmarker: boolean;
  isHeadshot: boolean;
  damageVignette: boolean;
  isGameOver: boolean;
  roundWinner: Team | null;
  winReason: string;
  killfeed: KillfeedEntry[];
  scoreboard: PlayerScoreData[];
  minimapData: {
    playerPos: { x: number; z: number };
    playerAngle: number;
    siteA: { x: number; z: number };
    siteB: { x: number; z: number };
    bombPos: { x: number; z: number } | null;
    entities: { x: number; z: number; team: Team; isAlive: boolean; isSpotted: boolean }[];
  };
}

export class GameEngine {
  private container: HTMLElement;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private renderer: THREE.WebGLRenderer;
  private mapData!: MapData;

  // Player State
  private playerTeam: Team = 'CT';
  private playerHp: number = 100;
  private playerArmor: number = 100;
  private playerKills: number = 0;
  private playerDeaths: number = 0;
  private playerPosition = new THREE.Vector3();
  private playerVelocity = new THREE.Vector3();
  private isGrounded: boolean = true;
  private isLocked: boolean = false;
  private pitch: number = 0;
  private yaw: number = 0;

  // Weapons & Inventory
  private currentWeaponType: 'rifle' | 'pistol' = 'rifle';
  private rifleRig!: WeaponRig;
  private pistolRig!: WeaponRig;
  private activeRig!: WeaponRig;
  private rifleAmmo = 30;
  private rifleReserve = 90;
  private pistolAmmo = 7;
  private pistolReserve = 35;
  private shootCooldown = 0;
  private isReloading = false;
  private reloadTimer = 0;
  private isAiming = false;
  private recoilPitch = 0;
  private recoilYaw = 0;
  private boltOffset = 0;

  // Effects & Visuals
  private bulletTracers: { line: THREE.Line; life: number }[] = [];
  private impactParticles: { mesh: THREE.Points; velocities: THREE.Vector3[]; life: number }[] = [];
  private flashDuration = 0;
  private hitmarkerTimer = 0;
  private isHitHeadshot = false;
  private damageVignetteTimer = 0;

  // Bomb System
  private bombState: BombState = {
    status: 'carried',
    timer: 40,
  };
  private c4Prop: { group: THREE.Group; ledLight: THREE.PointLight; ledMesh: THREE.Mesh } | null = null;
  private bombBeepTimer = 0;
  private interactHoldTime = 0;

  // Bots & Teams
  private bots: BotState[] = [];
  private gameMode: GameMode = 'defusal';
  private scoreT = 0;
  private scoreCT = 0;
  private roundTimer = 115; // 1:55
  private isGameOver = false;
  private roundWinner: Team | null = null;
  private winReason: string = '';
  private killfeed: KillfeedEntry[] = [];

  // Keys
  private keys: { [key: string]: boolean } = {};
  private mouseLeftDown = false;
  private mouseRightDown = false;

  // Lighting & Environment
  private dirLight!: THREE.DirectionalLight;
  private hemiLight!: THREE.HemisphereLight;

  // Callback to React
  private onHUDUpdate: (hud: HUDState) => void;
  private animationFrameId: number | null = null;
  private lastTime: number = performance.now();
  private footstepTimer: number = 0;

  constructor(
    container: HTMLElement,
    mapName: 'dust2' | 'house' | 'trenches',
    gameMode: GameMode,
    team: Team,
    onHUDUpdate: (hud: HUDState) => void
  ) {
    this.container = container;
    this.playerTeam = team;
    this.gameMode = gameMode;
    this.onHUDUpdate = onHUDUpdate;

    // Three.js Setup
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.05, 500);
    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.0;
    container.appendChild(this.renderer.domElement);

    // Load Map
    this.loadMap(mapName);

    // Setup Weapons
    this.setupWeapons();

    // Setup Bomb Prop
    this.c4Prop = createC4BombModel();
    this.c4Prop.group.visible = false;
    this.scene.add(this.c4Prop.group);

    // Setup Event Listeners
    this.bindEvents();

    // Start Round
    this.startRound();

    // Animation Loop
    this.lastTime = performance.now();
    this.tick = this.tick.bind(this);
    this.animationFrameId = requestAnimationFrame(this.tick);
  }

  public changeMap(mapName: 'dust2' | 'house' | 'trenches') {
    // Remove previous map objects
    for (const obj of this.mapData.objects) {
      this.scene.remove(obj);
    }
    this.loadMap(mapName);
    this.startRound();
  }

  public changeGameMode(mode: GameMode) {
    this.gameMode = mode;
    this.startRound();
  }

  public changeTeam(team: Team) {
    this.playerTeam = team;
    this.startRound();
  }

  private loadMap(mapName: 'dust2' | 'house' | 'trenches') {
    this.mapData = buildMap(mapName);

    this.scene.background = new THREE.Color(this.mapData.skyColor);
    this.scene.fog = new THREE.FogExp2(this.mapData.fogColor, this.mapData.fogDensity);

    // Lights
    if (!this.hemiLight) {
      this.hemiLight = new THREE.HemisphereLight(0xffffff, 0x444444, 0.7);
      this.scene.add(this.hemiLight);
    }
    this.hemiLight.color.setHex(this.mapData.skyColor);

    if (!this.dirLight) {
      this.dirLight = new THREE.DirectionalLight(this.mapData.lightColor, this.mapData.lightIntensity);
      this.dirLight.position.set(40, 70, 30);
      this.dirLight.castShadow = true;
      this.dirLight.shadow.mapSize.width = 2048;
      this.dirLight.shadow.mapSize.height = 2048;
      this.dirLight.shadow.camera.near = 0.5;
      this.dirLight.shadow.camera.far = 200;
      const d = 50;
      this.dirLight.shadow.camera.left = -d;
      this.dirLight.shadow.camera.right = d;
      this.dirLight.shadow.camera.top = d;
      this.dirLight.shadow.camera.bottom = -d;
      this.scene.add(this.dirLight);
    } else {
      this.dirLight.color.setHex(this.mapData.lightColor);
      this.dirLight.intensity = this.mapData.lightIntensity;
    }

    // Add map objects to scene
    for (const obj of this.mapData.objects) {
      this.scene.add(obj);
    }
  }

  private setupWeapons() {
    this.rifleRig = createRifleModel();
    this.pistolRig = createPistolModel();

    this.camera.add(this.rifleRig.group);
    this.camera.add(this.pistolRig.group);
    this.scene.add(this.camera);

    this.rifleRig.group.visible = true;
    this.pistolRig.group.visible = false;
    this.activeRig = this.rifleRig;
  }

  public switchWeapon(type: 'rifle' | 'pistol') {
    if (this.currentWeaponType === type || this.isReloading) return;
    this.currentWeaponType = type;
    if (type === 'rifle') {
      this.rifleRig.group.visible = true;
      this.pistolRig.group.visible = false;
      this.activeRig = this.rifleRig;
    } else {
      this.rifleRig.group.visible = false;
      this.pistolRig.group.visible = true;
      this.activeRig = this.pistolRig;
    }
    this.shootCooldown = 0.2;
  }

  private bindEvents() {
    const onKeyDown = (e: KeyboardEvent) => {
      this.keys[e.code] = true;

      if (e.code === 'Digit1') this.switchWeapon('rifle');
      if (e.code === 'Digit2') this.switchWeapon('pistol');
      if (e.code === 'KeyR') this.reload();

      // Pointer lock toggle when clicking or pressing space/enter
      if (!this.isLocked && (e.code === 'Space' || e.code === 'Enter')) {
        this.requestLock();
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      this.keys[e.code] = false;
    };

    const onMouseDown = (e: MouseEvent) => {
      if (!this.isLocked) {
        this.requestLock();
        return;
      }
      if (e.button === 0) this.mouseLeftDown = true;
      if (e.button === 2) this.mouseRightDown = true;
    };

    const onMouseUp = (e: MouseEvent) => {
      if (e.button === 0) this.mouseLeftDown = false;
      if (e.button === 2) this.mouseRightDown = false;
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!this.isLocked) return;
      const sensitivity = 0.0022;
      this.yaw -= e.movementX * sensitivity;
      this.pitch -= e.movementY * sensitivity;
      // Clamp pitch to avoid neck break
      this.pitch = Math.max(-Math.PI / 2.1, Math.min(Math.PI / 2.1, this.pitch));
    };

    const onResize = () => {
      this.camera.aspect = window.innerWidth / window.innerHeight;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(window.innerWidth, window.innerHeight);
    };

    const onPointerLockChange = () => {
      this.isLocked = document.pointerLockElement === this.container || document.pointerLockElement === this.renderer.domElement;
    };

    const onContextMenu = (e: MouseEvent) => e.preventDefault();

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    this.container.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mouseup', onMouseUp);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('resize', onResize);
    document.addEventListener('pointerlockchange', onPointerLockChange);
    this.container.addEventListener('contextmenu', onContextMenu);
  }

  public requestLock() {
    this.container.requestPointerLock?.();
  }

  public exitLock() {
    document.exitPointerLock?.();
  }

  public startRound() {
    this.isGameOver = false;
    this.roundWinner = null;
    this.winReason = '';
    this.roundTimer = this.gameMode === 'defusal' ? 115 : 180;
    this.playerHp = 100;
    this.playerArmor = 100;
    this.rifleAmmo = 30;
    this.rifleReserve = 90;
    this.pistolAmmo = 7;
    this.pistolReserve = 35;
    this.isReloading = false;
    this.recoilPitch = 0;
    this.recoilYaw = 0;

    // Reset Bomb
    if (this.c4Prop) {
      this.c4Prop.group.visible = false;
    }
    this.bombState = {
      status: this.playerTeam === 'T' ? 'carried' : 'carried',
      carrierName: this.playerTeam === 'T' ? 'Player' : undefined,
      timer: 40,
    };

    // Position Player at Spawn
    const spawns = this.playerTeam === 'T' ? this.mapData.tSpawns : this.mapData.ctSpawns;
    const mySpawn = spawns[0] || new THREE.Vector3(0, 1.6, 30);
    this.playerPosition.copy(mySpawn);
    this.playerVelocity.set(0, 0, 0);
    this.yaw = this.playerTeam === 'T' ? Math.PI : 0;
    this.pitch = 0;

    // Remove old bot meshes
    for (const b of this.bots) {
      this.scene.remove(b.model);
    }

    // Initialize Bots
    this.bots = initBots(this.playerTeam, this.mapData.patrolWaypoints);
    const tSpawns = this.mapData.tSpawns.slice(this.playerTeam === 'T' ? 1 : 0);
    const ctSpawns = this.mapData.ctSpawns.slice(this.playerTeam === 'CT' ? 1 : 0);

    let tIdx = 0;
    let ctIdx = 0;
    for (const b of this.bots) {
      if (b.team === 'T') {
        const s = tSpawns[tIdx % tSpawns.length] || new THREE.Vector3(0, 1.6, 40);
        b.position.copy(s);
        tIdx++;
      } else {
        const s = ctSpawns[ctIdx % ctSpawns.length] || new THREE.Vector3(0, 1.6, -40);
        b.position.copy(s);
        ctIdx++;
      }
      b.model.position.copy(b.position);
      this.scene.add(b.model);
    }

    audio.playRadio('Round Start!');
  }

  private reload() {
    if (this.isReloading) return;
    const isRifle = this.currentWeaponType === 'rifle';
    const ammo = isRifle ? this.rifleAmmo : this.pistolAmmo;
    const maxAmmo = isRifle ? 30 : 7;
    const reserve = isRifle ? this.rifleReserve : this.pistolReserve;

    if (ammo >= maxAmmo || reserve <= 0) return;

    this.isReloading = true;
    this.reloadTimer = 1.7;
    audio.playReloadSound();
  }

  private shoot() {
    if (this.shootCooldown > 0 || this.isReloading || this.playerHp <= 0) return;

    const isRifle = this.currentWeaponType === 'rifle';
    let ammo = isRifle ? this.rifleAmmo : this.pistolAmmo;
    if (ammo <= 0) {
      this.reload();
      return;
    }

    // Consume ammo
    if (isRifle) {
      this.rifleAmmo--;
      this.shootCooldown = 0.105; // ~570 RPM
    } else {
      this.pistolAmmo--;
      this.shootCooldown = 0.24;
    }

    // Sound
    audio.playShootSound(isRifle ? 'rifle' : 'pistol');

    // Muzzle Flash
    (this.activeRig.muzzleFlash.material as THREE.MeshBasicMaterial).opacity = 1.0;
    this.activeRig.muzzleLight.intensity = 3.5;
    this.flashDuration = 0.05;

    // Recoil
    const kick = isRifle ? 0.035 : 0.06;
    this.recoilPitch += kick * (this.isAiming ? 0.5 : 1.0);
    this.recoilYaw += (Math.random() - 0.5) * kick * 0.4;
    this.activeRig.group.position.z += 0.05;
    this.boltOffset = 0.04;

    // Raycast Shooting
    this.performRaycastShot();
  }

  private performRaycastShot() {
    const isRifle = this.currentWeaponType === 'rifle';
    const spreadAngle = (this.isAiming ? 0.005 : 0.02) * (this.playerVelocity.length() > 0.1 ? 2.2 : 1.0);

    const dir = new THREE.Vector3();
    this.camera.getWorldDirection(dir);
    dir.x += (Math.random() - 0.5) * spreadAngle;
    dir.y += (Math.random() - 0.5) * spreadAngle;
    dir.normalize();

    const raycaster = new THREE.Raycaster(this.camera.position, dir, 0.1, 150);

    // Get muzzle world position for tracer
    const muzzleWorld = new THREE.Vector3();
    this.activeRig.muzzleFlash.getWorldPosition(muzzleWorld);

    let hitPoint = this.camera.position.clone().addScaledVector(dir, 100);
    let hitSomething = false;
    let hitBot: BotState | null = null;
    let isHeadshot = false;

    // Check hit against living enemy bots
    let closestDist = 999;
    for (const b of this.bots) {
      if (!b.isAlive || b.team === this.playerTeam) continue;

      // Simple cylinder/box hit detection for bot
      const botPos = b.position;
      const headPos = botPos.clone().setY(botPos.y + 1.55);
      const bodyPos = botPos.clone().setY(botPos.y + 0.95);

      // Distance from ray to head
      const ray = raycaster.ray;
      const distToHead = ray.distanceToPoint(headPos);
      const distToBody = ray.distanceToPoint(bodyPos);

      const dToOrigin = this.camera.position.distanceTo(botPos);

      // Occlusion check
      if (!hasLineOfSight(this.camera.position, botPos, this.mapData.colliders)) {
        continue;
      }

      if (distToHead < 0.28 && dToOrigin < closestDist) {
        closestDist = dToOrigin;
        hitPoint = headPos;
        hitBot = b;
        isHeadshot = true;
        hitSomething = true;
      } else if (distToBody < 0.45 && dToOrigin < closestDist) {
        closestDist = dToOrigin;
        hitPoint = bodyPos;
        hitBot = b;
        isHeadshot = false;
        hitSomething = true;
      }
    }

    // Check wall collision if no bot or closer wall
    for (const c of this.mapData.colliders) {
      const box = new THREE.Box3(
        new THREE.Vector3(c.minX, c.minY, c.minZ),
        new THREE.Vector3(c.maxX, c.maxY, c.maxZ)
      );
      const intersect = raycaster.ray.intersectBox(box, new THREE.Vector3());
      if (intersect) {
        const d = this.camera.position.distanceTo(intersect);
        if (d < closestDist) {
          closestDist = d;
          hitPoint = intersect;
          hitBot = null;
          hitSomething = true;
        }
      }
    }

    // Create bullet tracer
    this.createTracer(muzzleWorld, hitPoint);

    // Apply Damage
    if (hitBot) {
      const damage = isHeadshot ? (isRifle ? 115 : 105) : (isRifle ? 36 : 48);
      this.damageBot(hitBot, damage, isHeadshot, 'Player', this.playerTeam);
      this.hitmarkerTimer = 0.2;
      this.isHitHeadshot = isHeadshot;
      audio.playHitmarker(isHeadshot);
    } else if (hitSomething) {
      this.createImpactSparks(hitPoint);
    }
  }

  private createTracer(start: THREE.Vector3, end: THREE.Vector3) {
    const geo = new THREE.BufferGeometry().setFromPoints([start, end]);
    const mat = new THREE.LineBasicMaterial({
      color: 0xffdd44,
      transparent: true,
      opacity: 0.85,
      linewidth: 2,
    });
    const line = new THREE.Line(geo, mat);
    this.scene.add(line);
    this.bulletTracers.push({ line, life: 0.08 });
  }

  private createImpactSparks(pos: THREE.Vector3) {
    const pCount = 8;
    const positions = new Float32Array(pCount * 3);
    const velocities: THREE.Vector3[] = [];

    for (let i = 0; i < pCount; i++) {
      positions[i * 3] = pos.x;
      positions[i * 3 + 1] = pos.y;
      positions[i * 3 + 2] = pos.z;
      velocities.push(
        new THREE.Vector3(
          (Math.random() - 0.5) * 4,
          Math.random() * 3 + 1,
          (Math.random() - 0.5) * 4
        )
      );
    }

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const mat = new THREE.PointsMaterial({
      color: 0xff9900,
      size: 0.08,
      transparent: true,
      opacity: 1,
    });
    const points = new THREE.Points(geo, mat);
    this.scene.add(points);
    this.impactParticles.push({ mesh: points, velocities, life: 0.25 });
  }

  private damageBot(bot: BotState, damage: number, headshot: boolean, killerName: string, killerTeam: Team) {
    if (!bot.isAlive) return;
    bot.hp = Math.max(0, bot.hp - damage);

    // Update HP bar
    const hpBar = bot.model.getObjectByName('hpBarFill') as THREE.Mesh;
    if (hpBar) {
      const pct = Math.max(0, bot.hp / bot.maxHp);
      hpBar.scale.x = pct;
      hpBar.position.x = -0.34 * (1 - pct);
    }

    if (bot.hp <= 0) {
      bot.isAlive = false;
      bot.deaths++;
      if (killerName === 'Player') {
        this.playerKills++;
      } else {
        const killerBot = this.bots.find(b => b.name === killerName);
        if (killerBot) killerBot.kills++;
      }

      this.killfeed.unshift({
        id: Math.random().toString(),
        killer: killerName,
        killerTeam,
        victim: bot.name,
        victimTeam: bot.team,
        weapon: this.currentWeaponType === 'rifle' ? 'AK-47' : 'Deagle',
        headshot,
        time: performance.now(),
      });
      if (this.killfeed.length > 5) this.killfeed.pop();

      // Drop bomb if bot was carrying it
      if (bot.carryingBomb) {
        bot.carryingBomb = false;
        this.bombState.status = 'dropped';
        this.bombState.position = bot.position.clone();
        if (this.c4Prop) {
          this.c4Prop.group.position.copy(bot.position);
          this.c4Prop.group.visible = true;
        }
      }

      // Check win condition
      this.checkRoundConditions();
    }
  }

  public damagePlayer(damage: number, attackerName: string, attackerTeam: Team) {
    if (this.playerHp <= 0) return;

    // Armor absorption
    const armorAbsorb = Math.min(this.playerArmor, damage * 0.4);
    this.playerArmor = Math.max(0, this.playerArmor - armorAbsorb);
    const remainingDmg = damage - armorAbsorb * 0.5;

    this.playerHp = Math.max(0, Math.floor(this.playerHp - remainingDmg));
    this.damageVignetteTimer = 0.35;
    audio.playPlayerHurt();

    if (this.playerHp <= 0) {
      this.playerDeaths++;
      this.killfeed.unshift({
        id: Math.random().toString(),
        killer: attackerName,
        killerTeam: attackerTeam,
        victim: 'Player',
        victimTeam: this.playerTeam,
        weapon: 'AK-47',
        headshot: false,
        time: performance.now(),
      });
      if (this.killfeed.length > 5) this.killfeed.pop();

      // Drop bomb if player was carrying
      if (this.bombState.carrierName === 'Player') {
        this.bombState.status = 'dropped';
        this.bombState.carrierName = undefined;
        this.bombState.position = this.playerPosition.clone();
        if (this.c4Prop) {
          this.c4Prop.group.position.copy(this.playerPosition);
          this.c4Prop.group.visible = true;
        }
      }

      this.checkRoundConditions();
    }
  }

  private checkRoundConditions() {
    if (this.isGameOver) return;

    const tAlive = (this.playerTeam === 'T' && this.playerHp > 0 ? 1 : 0) +
      this.bots.filter(b => b.team === 'T' && b.isAlive).length;

    const ctAlive = (this.playerTeam === 'CT' && this.playerHp > 0 ? 1 : 0) +
      this.bots.filter(b => b.team === 'CT' && b.isAlive).length;

    if (this.gameMode === 'tdm') {
      if (tAlive === 0) {
        this.finishRound('CT', 'All Terrorists eliminated');
      } else if (ctAlive === 0) {
        this.finishRound('T', 'All Counter-Terrorists eliminated');
      }
      return;
    }

    // Bomb Defusal mode
    if (this.bombState.status === 'exploded') {
      this.finishRound('T', 'Target Destroyed! Bomb Detonated');
    } else if (this.bombState.status === 'defused') {
      this.finishRound('CT', 'Bomb has been defused!');
    } else if (this.bombState.status === 'planted') {
      // If planted, CT must defuse even if Ts are dead!
      if (ctAlive === 0) {
        this.finishRound('T', 'All Counter-Terrorists eliminated');
      }
    } else {
      // Bomb not planted yet
      if (tAlive === 0) {
        this.finishRound('CT', 'All Terrorists eliminated');
      } else if (ctAlive === 0) {
        this.finishRound('T', 'All Counter-Terrorists eliminated');
      }
    }
  }

  private finishRound(winner: Team, reason: string) {
    if (this.isGameOver) return;
    this.isGameOver = true;
    this.roundWinner = winner;
    this.winReason = reason;

    if (winner === 'T') {
      this.scoreT++;
      audio.playRadio('Terrorists win');
    } else {
      this.scoreCT++;
      audio.playRadio('Counter-Terrorists win');
    }

    // Automatically start next round after 5 seconds
    setTimeout(() => {
      this.startRound();
    }, 5500);
  }

  private updatePlayer(dt: number) {
    if (this.playerHp <= 0) return;

    // Movement speeds
    const isSprinting = this.keys['ShiftLeft'] || this.keys['ShiftRight'];
    this.isAiming = this.mouseRightDown;
    const baseSpeed = this.isAiming ? 2.6 : isSprinting ? 7.2 : 4.8;

    // Direction from keys
    const forward = new THREE.Vector3(-Math.sin(this.yaw), 0, -Math.cos(this.yaw));
    const right = new THREE.Vector3(Math.cos(this.yaw), 0, -Math.sin(this.yaw));

    const moveDir = new THREE.Vector3();
    if (this.keys['KeyW']) moveDir.add(forward);
    if (this.keys['KeyS']) moveDir.sub(forward);
    if (this.keys['KeyD']) moveDir.add(right);
    if (this.keys['KeyA']) moveDir.sub(right);

    if (moveDir.lengthSq() > 0) {
      moveDir.normalize();
      this.playerVelocity.x = moveDir.x * baseSpeed;
      this.playerVelocity.z = moveDir.z * baseSpeed;

      // Footstep sound
      this.footstepTimer += dt * (isSprinting ? 1.5 : 1.0);
      if (this.footstepTimer >= 0.42) {
        audio.playFootstep(this.mapData.groundType);
        this.footstepTimer = 0;
      }
    } else {
      this.playerVelocity.x *= 0.75;
      this.playerVelocity.z *= 0.75;
    }

    // Jump & Gravity
    if (this.keys['Space'] && this.isGrounded) {
      this.playerVelocity.y = 5.8;
      this.isGrounded = false;
    }
    this.playerVelocity.y -= 16.0 * dt; // Gravity

    // Apply movement with AABB Collision Detection
    const nextPos = this.playerPosition.clone();
    nextPos.x += this.playerVelocity.x * dt;
    if (!checkCollision(nextPos, 0.45, this.mapData.colliders)) {
      this.playerPosition.x = nextPos.x;
    } else {
      this.playerVelocity.x = 0;
    }

    nextPos.copy(this.playerPosition);
    nextPos.z += this.playerVelocity.z * dt;
    if (!checkCollision(nextPos, 0.45, this.mapData.colliders)) {
      this.playerPosition.z = nextPos.z;
    } else {
      this.playerVelocity.z = 0;
    }

    this.playerPosition.y += this.playerVelocity.y * dt;
    // Ground floor check
    if (this.playerPosition.y <= 1.6) {
      this.playerPosition.y = 1.6;
      this.playerVelocity.y = 0;
      this.isGrounded = true;
    }

    // Update Camera position & rotation
    this.camera.position.copy(this.playerPosition);
    this.camera.rotation.set(0, 0, 0);
    this.camera.rotation.y = this.yaw + this.recoilYaw;
    this.camera.rotation.x = this.pitch + this.recoilPitch;

    // FOV Zoom for Aim Down Sights (ADS)
    const targetFov = this.isAiming ? 52 : 75;
    this.camera.fov = THREE.MathUtils.lerp(this.camera.fov, targetFov, dt * 14);
    this.camera.updateProjectionMatrix();

    // Recoil recovery
    this.recoilPitch = THREE.MathUtils.lerp(this.recoilPitch, 0, dt * 8);
    this.recoilYaw = THREE.MathUtils.lerp(this.recoilYaw, 0, dt * 8);
  }

  private updateWeapons(dt: number) {
    if (this.shootCooldown > 0) this.shootCooldown -= dt;

    // Reloading
    if (this.isReloading) {
      this.reloadTimer -= dt;
      // Weapon dip animation during reload
      this.activeRig.group.position.y = THREE.MathUtils.lerp(this.activeRig.group.position.y, -0.45, dt * 8);
      if (this.reloadTimer <= 0) {
        this.isReloading = false;
        const isRifle = this.currentWeaponType === 'rifle';
        if (isRifle) {
          const needed = 30 - this.rifleAmmo;
          const transfer = Math.min(needed, this.rifleReserve);
          this.rifleAmmo += transfer;
          this.rifleReserve -= transfer;
        } else {
          const needed = 7 - this.pistolAmmo;
          const transfer = Math.min(needed, this.pistolReserve);
          this.pistolAmmo += transfer;
          this.pistolReserve -= transfer;
        }
      }
    } else {
      // Weapon positioning (Hipfire vs ADS)
      const targetPos = this.isAiming ? this.activeRig.aimPosition : this.activeRig.defaultPosition;
      const targetRot = this.isAiming ? this.activeRig.aimRotation : this.activeRig.defaultRotation;

      // Weapon bobbing while moving
      let bobX = 0;
      let bobY = 0;
      if (this.playerVelocity.lengthSq() > 0.1 && this.isGrounded && !this.isAiming) {
        const t = performance.now() * 0.008;
        bobX = Math.sin(t) * 0.012;
        bobY = Math.abs(Math.cos(t)) * 0.012;
      }

      this.activeRig.group.position.x = THREE.MathUtils.lerp(this.activeRig.group.position.x, targetPos.x + bobX, dt * 12);
      this.activeRig.group.position.y = THREE.MathUtils.lerp(this.activeRig.group.position.y, targetPos.y + bobY, dt * 12);
      this.activeRig.group.position.z = THREE.MathUtils.lerp(this.activeRig.group.position.z, targetPos.z, dt * 12);

      this.activeRig.group.rotation.x = THREE.MathUtils.lerp(this.activeRig.group.rotation.x, targetRot.x, dt * 12);
      this.activeRig.group.rotation.y = THREE.MathUtils.lerp(this.activeRig.group.rotation.y, targetRot.y, dt * 12);
      this.activeRig.group.rotation.z = THREE.MathUtils.lerp(this.activeRig.group.rotation.z, targetRot.z, dt * 12);
    }

    // Flash decay
    if (this.flashDuration > 0) {
      this.flashDuration -= dt;
      if (this.flashDuration <= 0) {
        (this.activeRig.muzzleFlash.material as THREE.MeshBasicMaterial).opacity = 0;
        this.activeRig.muzzleLight.intensity = 0;
      }
    }

    // Bolt cycling animation
    if (this.activeRig.boltMesh) {
      this.boltOffset = THREE.MathUtils.lerp(this.boltOffset, 0, dt * 15);
      this.activeRig.boltMesh.position.z = -0.04 + this.boltOffset;
    }

    // Automatic fire (AK-47) or semi-auto (Pistol)
    if (this.mouseLeftDown) {
      this.shoot();
    }
  }

  private updateBots(dt: number) {
    for (const bot of this.bots) {
      if (!bot.isAlive) {
        // Death falling animation
        if (bot.deathAnimTimer < 1.0) {
          bot.deathAnimTimer += dt * 2.5;
          bot.model.rotation.x = THREE.MathUtils.lerp(bot.model.rotation.x, -Math.PI / 2, dt * 8);
          bot.model.position.y = THREE.MathUtils.lerp(bot.model.position.y, 0.2, dt * 8);
        }
        continue;
      }

      // Check for targets (Player or other bots)
      let nearestTarget: { position: THREE.Vector3; isPlayer: boolean; ref?: BotState } | null = null;
      let nearestDist = 999;

      // Check player
      if (this.playerTeam !== bot.team && this.playerHp > 0) {
        const d = bot.position.distanceTo(this.playerPosition);
        if (d < 50 && hasLineOfSight(bot.position, this.playerPosition, this.mapData.colliders)) {
          nearestTarget = { position: this.playerPosition, isPlayer: true };
          nearestDist = d;
        }
      }

      // Check enemy bots
      for (const other of this.bots) {
        if (other.team !== bot.team && other.isAlive) {
          const d = bot.position.distanceTo(other.position);
          if (d < nearestDist && hasLineOfSight(bot.position, other.position, this.mapData.colliders)) {
            nearestTarget = { position: other.position, isPlayer: false, ref: other };
            nearestDist = d;
          }
        }
      }

      bot.targetEnemy = nearestTarget;

      // Combat Behavior
      if (bot.targetEnemy) {
        // Turn towards target
        const dir = new THREE.Vector3().subVectors(bot.targetEnemy.position, bot.position);
        dir.y = 0;
        const targetAngle = Math.atan2(dir.x, dir.z);
        bot.model.rotation.y = THREE.MathUtils.lerp(bot.model.rotation.y, targetAngle, dt * 6);

        // Strafe or close in if too far
        if (nearestDist > 16) {
          dir.normalize();
          const next = bot.position.clone().addScaledVector(dir, 3.2 * dt);
          if (!checkCollision(next, 0.45, this.mapData.colliders)) {
            bot.position.copy(next);
          }
        }

        // Shoot at target
        bot.shootCooldown -= dt;
        if (bot.shootCooldown <= 0) {
          bot.shootCooldown = 0.12;
          bot.burstCount++;

          // Bullet sound & tracer
          audio.playShootSound('rifle');
          const botMuzzle = bot.position.clone().add(new THREE.Vector3(0.2, 1.0, 0.3));
          const hitTarget = bot.targetEnemy.position.clone().add(new THREE.Vector3(
            (Math.random() - 0.5) * 0.8,
            (Math.random() - 0.5) * 0.8,
            (Math.random() - 0.5) * 0.8
          ));
          this.createTracer(botMuzzle, hitTarget);

          // Apply damage if shot is accurate
          const hitChance = Math.max(0.25, 0.75 - nearestDist * 0.015);
          if (Math.random() < hitChance) {
            if (bot.targetEnemy.isPlayer) {
              this.damagePlayer(18 + Math.floor(Math.random() * 12), bot.name, bot.team);
            } else if (bot.targetEnemy.ref) {
              this.damageBot(bot.targetEnemy.ref, 24, false, bot.name, bot.team);
            }
          }

          if (bot.burstCount >= bot.burstMax) {
            bot.burstCount = 0;
            bot.shootCooldown = 0.5 + Math.random() * 0.6; // pause between bursts
          }
        }
      } else {
        // Objective Navigation (Bomb site or Patrol waypoints)
        let goalPos = this.mapData.patrolWaypoints[bot.currentWaypointIdx];

        if (this.gameMode === 'defusal') {
          if (bot.team === 'T') {
            if (bot.carryingBomb) {
              goalPos = this.mapData.siteA.center;
              // Check if at site A to plant
              if (bot.position.distanceTo(goalPos) < 4) {
                bot.isPlanting = true;
                bot.actionProgress += dt / 3.5;
                if (bot.actionProgress >= 1.0) {
                  this.plantBomb('A', bot.name);
                  bot.isPlanting = false;
                  bot.actionProgress = 0;
                }
              }
            } else if (this.bombState.status === 'planted') {
              goalPos = this.bombState.position || this.mapData.siteA.center;
            }
          } else {
            // CT
            if (this.bombState.status === 'planted' && this.bombState.position) {
              goalPos = this.bombState.position;
              // Check if at bomb to defuse
              if (bot.position.distanceTo(goalPos) < 3.5) {
                bot.isDefusing = true;
                bot.actionProgress += dt / 5.0;
                if (bot.actionProgress >= 1.0) {
                  this.defuseBomb(bot.name);
                  bot.isDefusing = false;
                  bot.actionProgress = 0;
                }
              }
            }
          }
        }

        if (goalPos) {
          const moveVec = new THREE.Vector3().subVectors(goalPos, bot.position);
          moveVec.y = 0;
          const distToGoal = moveVec.length();

          if (distToGoal < 2.0) {
            bot.currentWaypointIdx = (bot.currentWaypointIdx + 1) % this.mapData.patrolWaypoints.length;
          } else {
            moveVec.normalize();
            const angle = Math.atan2(moveVec.x, moveVec.z);
            bot.model.rotation.y = THREE.MathUtils.lerp(bot.model.rotation.y, angle, dt * 5);

            const next = bot.position.clone().addScaledVector(moveVec, 3.6 * dt);
            if (!checkCollision(next, 0.45, this.mapData.colliders)) {
              bot.position.copy(next);
            } else {
              // Path obstacle: change waypoint
              bot.currentWaypointIdx = (bot.currentWaypointIdx + 1) % this.mapData.patrolWaypoints.length;
            }
          }
        }
      }

      // Animate bot walking legs
      const legL = bot.model.getObjectByName('legL');
      const legR = bot.model.getObjectByName('legR');
      if (legL && legR) {
        const t = performance.now() * 0.008;
        legL.rotation.x = Math.sin(t) * 0.5;
        legR.rotation.x = -Math.sin(t) * 0.5;
      }

      bot.model.position.copy(bot.position);
    }
  }

  private plantBomb(site: 'A' | 'B', planterName: string) {
    this.bombState.status = 'planted';
    this.bombState.site = site;
    this.bombState.timer = 40;
    const plantPos = site === 'A' ? this.mapData.siteA.center.clone() : this.mapData.siteB.center.clone();
    plantPos.y = 0.05;
    this.bombState.position = plantPos;

    if (this.c4Prop) {
      this.c4Prop.group.position.copy(plantPos);
      this.c4Prop.group.visible = true;
    }

    audio.playRadio('Bomb has been planted');
    this.killfeed.unshift({
      id: Math.random().toString(),
      killer: planterName,
      killerTeam: 'T',
      victim: `Planted at Site ${site}`,
      victimTeam: 'T',
      weapon: 'C4',
      headshot: false,
      time: performance.now(),
    });
  }

  private defuseBomb(defuserName: string) {
    this.bombState.status = 'defused';
    audio.playBombDefused();
    audio.playRadio('Bomb has been defused');
    this.killfeed.unshift({
      id: Math.random().toString(),
      killer: defuserName,
      killerTeam: 'CT',
      victim: 'Defused C4',
      victimTeam: 'CT',
      weapon: 'Defuse Kit',
      headshot: false,
      time: performance.now(),
    });
    this.finishRound('CT', 'Bomb has been defused');
  }

  private updateBomb(dt: number) {
    if (this.bombState.status === 'planted') {
      this.bombState.timer -= dt;

      // Accelerated bomb beeping
      const pct = Math.max(0.05, this.bombState.timer / 40);
      const beepInterval = 0.12 + pct * 0.95;
      this.bombBeepTimer += dt;
      if (this.bombBeepTimer >= beepInterval) {
        this.bombBeepTimer = 0;
        const pitchMult = 1.0 + (1 - pct) * 0.8;
        audio.playBombBeep(pitchMult);

        if (this.c4Prop) {
          this.c4Prop.ledLight.intensity = 2.5;
          setTimeout(() => {
            if (this.c4Prop) this.c4Prop.ledLight.intensity = 0;
          }, 60);
        }
      }

      // Detonation
      if (this.bombState.timer <= 0) {
        this.bombState.status = 'exploded';
        audio.playBombExplosion();
        audio.playRadio('Terrorists win');

        // Kill players and bots nearby
        const blastCenter = this.bombState.position || this.mapData.siteA.center;
        if (this.playerPosition.distanceTo(blastCenter) < 40) {
          this.damagePlayer(250, 'C4 Explosion', 'T');
        }
        for (const b of this.bots) {
          if (b.position.distanceTo(blastCenter) < 40) {
            this.damageBot(b, 250, false, 'C4 Explosion', 'T');
          }
        }

        this.finishRound('T', 'Target Destroyed! Bomb Detonated');
      }
    }
  }

  private updatePlayerInteraction(dt: number): { prompt: string | null; progress: number } {
    if (this.playerHp <= 0 || this.isGameOver) return { prompt: null, progress: 0 };

    let prompt: string | null = null;
    let progress = 0;

    if (this.gameMode === 'defusal') {
      if (this.playerTeam === 'T' && this.bombState.carrierName === 'Player') {
        // Check if inside site A or B
        const distA = this.playerPosition.distanceTo(this.mapData.siteA.center);
        const distB = this.playerPosition.distanceTo(this.mapData.siteB.center);
        const insideA = distA <= this.mapData.siteA.radius;
        const insideB = distB <= this.mapData.siteB.radius;

        if (insideA || insideB) {
          const site = insideA ? 'A' : 'B';
          prompt = `Зажмите [E] для закладки C4 (Точка ${site})`;

          if (this.keys['KeyE']) {
            this.interactHoldTime += dt;
            progress = Math.min(1.0, this.interactHoldTime / 3.5);
            audio.playBombPlantBeeps();
            if (this.interactHoldTime >= 3.5) {
              this.plantBomb(site, 'Player');
              this.interactHoldTime = 0;
            }
          } else {
            this.interactHoldTime = 0;
          }
        } else {
          this.interactHoldTime = 0;
        }
      } else if (this.playerTeam === 'CT' && this.bombState.status === 'planted' && this.bombState.position) {
        // Check if near planted bomb
        const distToBomb = this.playerPosition.distanceTo(this.bombState.position);
        if (distToBomb <= 3.2) {
          prompt = 'Зажмите [E] для разминирования C4';
          if (this.keys['KeyE']) {
            this.interactHoldTime += dt;
            progress = Math.min(1.0, this.interactHoldTime / 5.0);
            if (this.interactHoldTime >= 5.0) {
              this.defuseBomb('Player');
              this.interactHoldTime = 0;
            }
          } else {
            this.interactHoldTime = 0;
          }
        } else {
          this.interactHoldTime = 0;
        }
      }
    }

    return { prompt, progress };
  }

  private updateTracersAndParticles(dt: number) {
    // Tracers
    for (let i = this.bulletTracers.length - 1; i >= 0; i--) {
      const t = this.bulletTracers[i];
      t.life -= dt;
      if (t.life <= 0) {
        this.scene.remove(t.line);
        t.line.geometry.dispose();
        this.bulletTracers.splice(i, 1);
      }
    }

    // Particles
    for (let i = this.impactParticles.length - 1; i >= 0; i--) {
      const p = this.impactParticles[i];
      p.life -= dt;
      const posAttr = p.mesh.geometry.getAttribute('position') as THREE.BufferAttribute;
      for (let j = 0; j < p.velocities.length; j++) {
        p.velocities[j].y -= 9.8 * dt;
        posAttr.setXYZ(
          j,
          posAttr.getX(j) + p.velocities[j].x * dt,
          posAttr.getY(j) + p.velocities[j].y * dt,
          posAttr.getZ(j) + p.velocities[j].z * dt
        );
      }
      posAttr.needsUpdate = true;

      if (p.life <= 0) {
        this.scene.remove(p.mesh);
        p.mesh.geometry.dispose();
        this.impactParticles.splice(i, 1);
      }
    }

    // Timers
    if (this.hitmarkerTimer > 0) this.hitmarkerTimer -= dt;
    if (this.damageVignetteTimer > 0) this.damageVignetteTimer -= dt;
  }

  private tick() {
    const now = performance.now();
    const dt = Math.min(0.1, (now - this.lastTime) / 1000);
    this.lastTime = now;

    // Round countdown
    if (!this.isGameOver) {
      this.roundTimer -= dt;
      if (this.roundTimer <= 0) {
        this.roundTimer = 0;
        if (this.gameMode === 'defusal') {
          // If time expires in defusal and bomb isn't planted, CT wins
          this.finishRound('CT', 'Time expired: Counter-Terrorists win');
        } else {
          // TDM: whoever has more kills
          const tScore = this.scoreT + this.bots.filter(b => b.team === 'T').reduce((a, b) => a + b.kills, 0);
          const ctScore = this.scoreCT + this.bots.filter(b => b.team === 'CT').reduce((a, b) => a + b.kills, 0);
          this.finishRound(tScore >= ctScore ? 'T' : 'CT', 'Time expired');
        }
      }
    }

    // Update Subsystems
    this.updatePlayer(dt);
    this.updateWeapons(dt);
    this.updateBots(dt);
    this.updateBomb(dt);
    const interaction = this.updatePlayerInteraction(dt);
    this.updateTracersAndParticles(dt);

    // Render Scene
    this.renderer.render(this.scene, this.camera);

    // Build Scoreboard data
    const scoreboard: PlayerScoreData[] = [
      {
        id: 'player',
        name: 'Player (You)',
        team: this.playerTeam,
        kills: this.playerKills,
        deaths: this.playerDeaths,
        score: this.playerKills * 2 - this.playerDeaths,
        ping: 5,
        isAlive: this.playerHp > 0,
        isPlayer: true,
      },
      ...this.bots.map(b => ({
        id: b.id,
        name: b.name,
        team: b.team,
        kills: b.kills,
        deaths: b.deaths,
        score: b.kills * 2 - b.deaths,
        ping: b.ping,
        isAlive: b.isAlive,
        isPlayer: false,
      })),
    ];

    // Minimap data
    const minimapEntities = this.bots.map(b => ({
      x: b.position.x,
      z: b.position.z,
      team: b.team,
      isAlive: b.isAlive,
      isSpotted: b.team === this.playerTeam || hasLineOfSight(this.playerPosition, b.position, this.mapData.colliders),
    }));

    // Emit HUD state to React
    this.onHUDUpdate({
      hp: this.playerHp,
      armor: this.playerArmor,
      ammo: this.currentWeaponType === 'rifle' ? this.rifleAmmo : this.pistolAmmo,
      reserveAmmo: this.currentWeaponType === 'rifle' ? this.rifleReserve : this.pistolReserve,
      weaponName: this.currentWeaponType === 'rifle' ? 'AK-47' : 'Desert Eagle',
      isReloading: this.isReloading,
      isAiming: this.isAiming,
      team: this.playerTeam,
      scoreT: this.scoreT,
      scoreCT: this.scoreCT,
      roundTimer: Math.ceil(this.roundTimer),
      gameMode: this.gameMode,
      mapName: this.mapData.displayName,
      bombState: this.bombState,
      interactPrompt: interaction.prompt,
      interactProgress: interaction.progress,
      hitmarker: this.hitmarkerTimer > 0,
      isHeadshot: this.isHitHeadshot,
      damageVignette: this.damageVignetteTimer > 0,
      isGameOver: this.isGameOver,
      roundWinner: this.roundWinner,
      winReason: this.winReason,
      killfeed: this.killfeed,
      scoreboard,
      minimapData: {
        playerPos: { x: this.playerPosition.x, z: this.playerPosition.z },
        playerAngle: this.yaw,
        siteA: { x: this.mapData.siteA.center.x, z: this.mapData.siteA.center.z },
        siteB: { x: this.mapData.siteB.center.x, z: this.mapData.siteB.center.z },
        bombPos: this.bombState.position ? { x: this.bombState.position.x, z: this.bombState.position.z } : null,
        entities: minimapEntities,
      },
    });

    this.animationFrameId = requestAnimationFrame(this.tick);
  }

  public destroy() {
    if (this.animationFrameId !== null) {
      cancelAnimationFrame(this.animationFrameId);
    }
    this.renderer.dispose();
    if (this.container.contains(this.renderer.domElement)) {
      this.container.removeChild(this.renderer.domElement);
    }
  }
}
