import * as THREE from 'three';
import { getProceduralTexture } from './proceduralTextures';

export interface BoundingBox2D {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  minY: number;
  maxY: number;
}

export interface MapData {
  name: string;
  displayName: string;
  objects: THREE.Object3D[];
  colliders: BoundingBox2D[];
  tSpawns: THREE.Vector3[];
  ctSpawns: THREE.Vector3[];
  siteA: { center: THREE.Vector3; radius: number };
  siteB: { center: THREE.Vector3; radius: number };
  patrolWaypoints: THREE.Vector3[];
  skyColor: number;
  fogColor: number;
  fogDensity: number;
  lightColor: number;
  lightIntensity: number;
  groundType: 'sand' | 'wood' | 'grass';
}

function addBox(
  objects: THREE.Object3D[],
  colliders: BoundingBox2D[],
  x: number,
  y: number,
  z: number,
  w: number,
  h: number,
  d: number,
  material: THREE.Material,
  hasCollision: boolean = true
): THREE.Mesh {
  const geo = new THREE.BoxGeometry(w, h, d);
  const mesh = new THREE.Mesh(geo, material);
  mesh.position.set(x, y + h / 2, z);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  objects.push(mesh);

  if (hasCollision) {
    colliders.push({
      minX: x - w / 2,
      maxX: x + w / 2,
      minZ: z - d / 2,
      maxZ: z + d / 2,
      minY: y,
      maxY: y + h,
    });
  }

  return mesh;
}

// -------------------------------------------------------------
// MAP 1: DUST 2 (de_dust2)
// -------------------------------------------------------------
export function buildDust2Map(): MapData {
  const objects: THREE.Object3D[] = [];
  const colliders: BoundingBox2D[] = [];

  const sandWallTex = getProceduralTexture('sandstone');
  sandWallTex.repeat.set(2, 2);
  const sandWallMat = new THREE.MeshStandardMaterial({
    map: sandWallTex,
    roughness: 0.85,
  });

  const groundTex = getProceduralTexture('dust_ground');
  groundTex.repeat.set(16, 16);
  const groundMat = new THREE.MeshStandardMaterial({
    map: groundTex,
    roughness: 0.9,
  });

  const crateTex = getProceduralTexture('wood_crate');
  crateTex.repeat.set(1, 1);
  const crateMat = new THREE.MeshStandardMaterial({
    map: crateTex,
    roughness: 0.7,
  });

  const containerTex = getProceduralTexture('metal_container');
  containerTex.repeat.set(2, 1);
  const containerMat = new THREE.MeshStandardMaterial({
    map: containerTex,
    metalness: 0.5,
    roughness: 0.4,
  });

  const siteATex = getProceduralTexture('site_a');
  const siteAMat = new THREE.MeshBasicMaterial({ map: siteATex, transparent: true });

  const siteBTex = getProceduralTexture('site_b');
  const siteBMat = new THREE.MeshBasicMaterial({ map: siteBTex, transparent: true });

  // Ground Plane (80 x 100)
  const groundGeo = new THREE.PlaneGeometry(100, 120);
  const ground = new THREE.Mesh(groundGeo, groundMat);
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = true;
  objects.push(ground);

  // Outer Border Walls (prevent falling off)
  const wallH = 7;
  addBox(objects, colliders, 0, 0, -60, 100, wallH, 3, sandWallMat);
  addBox(objects, colliders, 0, 0, 60, 100, wallH, 3, sandWallMat);
  addBox(objects, colliders, -50, 0, 0, 3, wallH, 120, sandWallMat);
  addBox(objects, colliders, 50, 0, 0, 3, wallH, 120, sandWallMat);

  // --- Long A Lane (Right side X: 15 to 40, Z: -50 to 30) ---
  addBox(objects, colliders, 20, 0, 0, 3, wallH, 60, sandWallMat);
  // Pit on Long
  addBox(objects, colliders, 36, 0, 35, 12, 1.2, 8, sandWallMat, false);

  // Site A Platform (X: 30, Z: -36)
  addBox(objects, colliders, 32, 0, -36, 18, 1.5, 18, sandWallMat);
  // Site A Decal
  const decalA = new THREE.Mesh(new THREE.PlaneGeometry(5, 5), siteAMat);
  decalA.rotation.x = -Math.PI / 2;
  decalA.position.set(32, 1.52, -36);
  objects.push(decalA);

  // Crates on Site A
  addBox(objects, colliders, 30, 1.5, -34, 2.5, 2.5, 2.5, crateMat);
  addBox(objects, colliders, 33, 1.5, -34, 2.5, 2.5, 2.5, crateMat);
  addBox(objects, colliders, 31.5, 4.0, -34, 2.5, 2.5, 2.5, crateMat);
  addBox(objects, colliders, 25, 0, -25, 3, 3, 3, containerMat);

  // --- Middle Area (Mid Doors & Mid to B) ---
  addBox(objects, colliders, -8, 0, -10, 3, wallH, 40, sandWallMat);
  // Mid Double Doors opening
  addBox(objects, colliders, 5, 0, -15, 6, wallH, 2.5, sandWallMat);
  addBox(objects, colliders, -4, 0, -15, 6, wallH, 2.5, sandWallMat);
  // Door props
  const doorMat = new THREE.MeshStandardMaterial({ color: 0x2b4c5b, metalness: 0.6 });
  addBox(objects, colliders, -0.6, 0, -15.5, 0.4, 5, 2.4, doorMat, true);

  // Mid Crates / Xbox
  addBox(objects, colliders, 4, 0, 5, 3.2, 3.2, 3.2, crateMat);
  addBox(objects, colliders, 4, 3.2, 5, 2.5, 2.5, 2.5, crateMat);

  // --- Site B (X: -32, Z: -36) & B Tunnels ---
  // Tunnels walls
  addBox(objects, colliders, -24, 0, 10, 3, wallH, 45, sandWallMat);
  addBox(objects, colliders, -38, 0, 15, 3, wallH, 35, sandWallMat);
  // Tunnel roof
  const tunnelRoof = new THREE.Mesh(new THREE.BoxGeometry(15, 1, 35), sandWallMat);
  tunnelRoof.position.set(-31, wallH, 15);
  objects.push(tunnelRoof);

  // Site B Platform
  addBox(objects, colliders, -32, 0, -36, 22, 1.2, 22, sandWallMat);
  // Site B Decal
  const decalB = new THREE.Mesh(new THREE.PlaneGeometry(5, 5), siteBMat);
  decalB.rotation.x = -Math.PI / 2;
  decalB.position.set(-32, 1.22, -36);
  objects.push(decalB);

  // Site B Crates and Container
  addBox(objects, colliders, -35, 1.2, -34, 3, 3, 3, containerMat);
  addBox(objects, colliders, -30, 1.2, -38, 2.6, 2.6, 2.6, crateMat);
  addBox(objects, colliders, -26, 1.2, -32, 2.6, 2.6, 2.6, crateMat);
  addBox(objects, colliders, -26, 3.8, -32, 2.2, 2.2, 2.2, crateMat);

  // Back of B Site Wall
  addBox(objects, colliders, -32, 0, -48, 26, wallH, 3, sandWallMat);

  // CT Spawn Arch & Cover (Z: -45, X: 0)
  addBox(objects, colliders, -6, 0, -45, 2, wallH, 12, sandWallMat);
  addBox(objects, colliders, 6, 0, -45, 2, wallH, 12, sandWallMat);
  addBox(objects, colliders, 0, 5, -45, 14, 2, 2, sandWallMat, false);

  // T Spawn Cover & Barriers (Z: 45, X: 0)
  addBox(objects, colliders, -8, 0, 42, 6, 2.5, 2, sandWallMat);
  addBox(objects, colliders, 8, 0, 42, 6, 2.5, 2, sandWallMat);
  addBox(objects, colliders, 0, 0, 36, 4, 2.5, 4, crateMat);

  return {
    name: 'dust2',
    displayName: 'de_dust2 (Dust 2)',
    objects,
    colliders,
    tSpawns: [
      new THREE.Vector3(0, 1.6, 48),
      new THREE.Vector3(-6, 1.6, 50),
      new THREE.Vector3(6, 1.6, 50),
      new THREE.Vector3(-12, 1.6, 48),
    ],
    ctSpawns: [
      new THREE.Vector3(0, 1.6, -45),
      new THREE.Vector3(8, 1.6, -44),
      new THREE.Vector3(-8, 1.6, -44),
      new THREE.Vector3(16, 1.6, -42),
    ],
    siteA: { center: new THREE.Vector3(32, 1.5, -36), radius: 6 },
    siteB: { center: new THREE.Vector3(-32, 1.2, -36), radius: 6 },
    patrolWaypoints: [
      new THREE.Vector3(0, 1.6, 30),
      new THREE.Vector3(32, 1.6, 25), // Long doors
      new THREE.Vector3(32, 1.6, 0), // Long A
      new THREE.Vector3(32, 1.6, -34), // Site A
      new THREE.Vector3(0, 1.6, 10), // Mid
      new THREE.Vector3(0, 1.6, -20), // Mid to B
      new THREE.Vector3(-32, 1.6, 15), // B Tunnels
      new THREE.Vector3(-32, 1.6, -34), // Site B
      new THREE.Vector3(0, 1.6, -42), // CT spawn
    ],
    skyColor: 0x90bfe8,
    fogColor: 0xd4c2a5,
    fogDensity: 0.003,
    lightColor: 0xfff3db,
    lightIntensity: 1.4,
    groundType: 'sand',
  };
}

// -------------------------------------------------------------
// MAP 2: HOUSE / CLOSE QUARTERS (cs_office style compound)
// -------------------------------------------------------------
export function buildHouseMap(): MapData {
  const objects: THREE.Object3D[] = [];
  const colliders: BoundingBox2D[] = [];

  const wallTex = getProceduralTexture('wallpaper');
  wallTex.repeat.set(4, 2);
  const wallMat = new THREE.MeshStandardMaterial({
    map: wallTex,
    roughness: 0.6,
  });

  const concreteTex = getProceduralTexture('concrete');
  concreteTex.repeat.set(4, 4);
  const concreteMat = new THREE.MeshStandardMaterial({
    map: concreteTex,
    roughness: 0.8,
  });

  const floorTex = getProceduralTexture('wood_floor');
  floorTex.repeat.set(8, 8);
  const woodFloorMat = new THREE.MeshStandardMaterial({
    map: floorTex,
    roughness: 0.4,
  });

  const crateTex = getProceduralTexture('wood_crate');
  const crateMat = new THREE.MeshStandardMaterial({ map: crateTex, roughness: 0.7 });

  const siteATex = getProceduralTexture('site_a');
  const siteAMat = new THREE.MeshBasicMaterial({ map: siteATex, transparent: true });

  const siteBTex = getProceduralTexture('site_b');
  const siteBMat = new THREE.MeshBasicMaterial({ map: siteBTex, transparent: true });

  // Ground courtyard & ground floor
  const groundGeo = new THREE.PlaneGeometry(80, 80);
  const ground = new THREE.Mesh(groundGeo, concreteMat);
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = true;
  objects.push(ground);

  // Perimeter garden/courtyard walls
  const outerH = 6;
  addBox(objects, colliders, 0, 0, -38, 76, outerH, 2, concreteMat);
  addBox(objects, colliders, 0, 0, 38, 76, outerH, 2, concreteMat);
  addBox(objects, colliders, -38, 0, 0, 2, outerH, 76, concreteMat);
  addBox(objects, colliders, 38, 0, 0, 2, outerH, 76, concreteMat);

  // Two-Story Mansion (Width: 44, Depth: 40, Height: 7)
  const h1 = 3.6; // Ground floor height
  const h2 = 3.4; // Second floor height

  // Floor 1 Wood Floor interior
  const interiorFloor = new THREE.Mesh(new THREE.BoxGeometry(44, 0.2, 40), woodFloorMat);
  interiorFloor.position.set(0, 0.1, 0);
  objects.push(interiorFloor);

  // Exterior House Walls
  // South Wall (with entrance doorway)
  addBox(objects, colliders, -14, 0, 20, 16, h1 + h2, 1.5, wallMat);
  addBox(objects, colliders, 14, 0, 20, 16, h1 + h2, 1.5, wallMat);
  addBox(objects, colliders, 0, 2.6, 20, 12, h1 + h2 - 2.6, 1.5, wallMat); // Entrance arch

  // North Wall (Backyard)
  addBox(objects, colliders, -12, 0, -20, 20, h1 + h2, 1.5, wallMat);
  addBox(objects, colliders, 12, 0, -20, 20, h1 + h2, 1.5, wallMat);
  addBox(objects, colliders, 0, 2.6, -20, 6, h1 + h2 - 2.6, 1.5, wallMat);

  // East & West Exterior Walls
  addBox(objects, colliders, -22, 0, 0, 1.5, h1 + h2, 40, wallMat);
  addBox(objects, colliders, 22, 0, 0, 1.5, h1 + h2, 40, wallMat);

  // Second Floor Ceiling / Floor separator (with stair opening at X: -10, Z: -6)
  const floor2_A = new THREE.Mesh(new THREE.BoxGeometry(26, 0.4, 38), woodFloorMat);
  floor2_A.position.set(9, h1, 0);
  objects.push(floor2_A);

  const floor2_B = new THREE.Mesh(new THREE.BoxGeometry(14, 0.4, 20), woodFloorMat);
  floor2_B.position.set(-14, h1, 9);
  objects.push(floor2_B);

  // Staircase (ramp) leading to second floor
  const stairGeo = new THREE.BoxGeometry(3.5, 0.3, 10);
  const stairMesh = new THREE.Mesh(stairGeo, woodFloorMat);
  stairMesh.position.set(-13, h1 / 2, -5);
  stairMesh.rotation.x = 0.37;
  objects.push(stairMesh);
  colliders.push({
    minX: -15,
    maxX: -11,
    minZ: -10,
    maxZ: 0,
    minY: 0,
    maxY: h1,
  });

  // Interior Partitions (Ground Floor Rooms)
  // Living room wall (Left side)
  addBox(objects, colliders, -6, 0, 6, 1.2, h1, 14, wallMat);
  // Kitchen / Dining wall (Right side)
  addBox(objects, colliders, 8, 0, -4, 16, h1, 1.2, wallMat);

  // Second floor interior balcony railing
  const railMat = new THREE.MeshStandardMaterial({ color: 0x111111, metalness: 0.8 });
  addBox(objects, colliders, -4, h1, 0, 0.3, 1.1, 16, railMat);

  // Site A: Living Room Ground Floor (X: 12, Z: 10)
  const decalA = new THREE.Mesh(new THREE.PlaneGeometry(4, 4), siteAMat);
  decalA.rotation.x = -Math.PI / 2;
  decalA.position.set(12, 0.22, 10);
  objects.push(decalA);

  // Site B: Master Bedroom Second Floor (X: 10, Z: -10)
  const decalB = new THREE.Mesh(new THREE.PlaneGeometry(4, 4), siteBMat);
  decalB.rotation.x = -Math.PI / 2;
  decalB.position.set(10, h1 + 0.22, -10);
  objects.push(decalB);

  // Furniture / Props (Tables, Sofas, Desks, Crates)
  const woodTableMat = new THREE.MeshStandardMaterial({ color: 0x4a2f1b, roughness: 0.5 });
  // Living room dining table
  addBox(objects, colliders, 12, 0, 10, 4, 1.0, 2.5, woodTableMat);
  // Sofa
  const sofaMat = new THREE.MeshStandardMaterial({ color: 0x223344, roughness: 0.9 });
  addBox(objects, colliders, -12, 0, 12, 4.5, 1.1, 1.8, sofaMat);
  // TV stand / console
  addBox(objects, colliders, -12, 0, 18, 3.5, 0.8, 1.0, woodTableMat);

  // Bedroom 2nd floor desk and bed
  addBox(objects, colliders, 16, h1, -14, 3.5, 0.9, 1.8, woodTableMat);
  addBox(objects, colliders, 6, h1, -14, 4.0, 0.8, 4.0, sofaMat);

  // Outside Courtyard cover crates
  addBox(objects, colliders, -16, 0, 28, 2.5, 2.5, 2.5, crateMat);
  addBox(objects, colliders, 14, 0, 28, 2.5, 2.5, 2.5, crateMat);
  addBox(objects, colliders, 0, 0, -28, 3.0, 2.0, 5.0, concreteMat);

  return {
    name: 'house',
    displayName: 'cs_mansion (House / Close Quarters)',
    objects,
    colliders,
    tSpawns: [
      new THREE.Vector3(0, 1.6, 32),
      new THREE.Vector3(-6, 1.6, 34),
      new THREE.Vector3(6, 1.6, 34),
      new THREE.Vector3(-12, 1.6, 32),
    ],
    ctSpawns: [
      new THREE.Vector3(0, 1.6, -32),
      new THREE.Vector3(8, 1.6, -34),
      new THREE.Vector3(-8, 1.6, -34),
      new THREE.Vector3(14, 1.6, -32),
    ],
    siteA: { center: new THREE.Vector3(12, 0.2, 10), radius: 5 },
    siteB: { center: new THREE.Vector3(10, h1 + 0.2, -10), radius: 5 },
    patrolWaypoints: [
      new THREE.Vector3(0, 1.6, 24), // Main entrance
      new THREE.Vector3(0, 1.6, 12), // Foyer
      new THREE.Vector3(12, 1.6, 10), // Site A
      new THREE.Vector3(-12, 1.6, 10), // Living room
      new THREE.Vector3(-13, 1.6, -2), // Bottom of stairs
      new THREE.Vector3(-13, h1 + 1.6, 2), // Top of stairs
      new THREE.Vector3(0, h1 + 1.6, 0), // 2nd floor hallway
      new THREE.Vector3(10, h1 + 1.6, -10), // Site B
      new THREE.Vector3(0, 1.6, -12), // Back room
      new THREE.Vector3(0, 1.6, -25), // Backyard CT spawn
    ],
    skyColor: 0x76899e,
    fogColor: 0x5a6875,
    fogDensity: 0.005,
    lightColor: 0xffeedd,
    lightIntensity: 1.2,
    groundType: 'wood',
  };
}

// -------------------------------------------------------------
// MAP 3: FOREST & TRENCHES (de_trenches)
// -------------------------------------------------------------
export function buildTrenchesMap(): MapData {
  const objects: THREE.Object3D[] = [];
  const colliders: BoundingBox2D[] = [];

  const grassTex = getProceduralTexture('grass');
  grassTex.repeat.set(16, 16);
  const grassMat = new THREE.MeshStandardMaterial({
    map: grassTex,
    roughness: 0.95,
  });

  const dirtTex = getProceduralTexture('dirt_trench');
  dirtTex.repeat.set(4, 4);
  const dirtMat = new THREE.MeshStandardMaterial({
    map: dirtTex,
    roughness: 0.95,
  });

  const barkTex = getProceduralTexture('tree_bark');
  barkTex.repeat.set(1, 4);
  const barkMat = new THREE.MeshStandardMaterial({
    map: barkTex,
    roughness: 0.85,
  });

  const foliageMat = new THREE.MeshStandardMaterial({
    color: 0x224418,
    roughness: 0.9,
  });

  const woodBoardMat = new THREE.MeshStandardMaterial({
    color: 0x543c22,
    roughness: 0.8,
  });

  const sandbagMat = new THREE.MeshStandardMaterial({
    color: 0x9e8867,
    roughness: 0.95,
  });

  const siteATex = getProceduralTexture('site_a');
  const siteAMat = new THREE.MeshBasicMaterial({ map: siteATex, transparent: true });

  const siteBTex = getProceduralTexture('site_b');
  const siteBMat = new THREE.MeshBasicMaterial({ map: siteBTex, transparent: true });

  // Main ground
  const groundGeo = new THREE.PlaneGeometry(100, 120);
  const ground = new THREE.Mesh(groundGeo, grassMat);
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = true;
  objects.push(ground);

  // Outer natural rock/cliff barriers
  const borderMat = new THREE.MeshStandardMaterial({ color: 0x48423c, roughness: 0.9 });
  addBox(objects, colliders, 0, 0, -60, 100, 8, 4, borderMat);
  addBox(objects, colliders, 0, 0, 60, 100, 8, 4, borderMat);
  addBox(objects, colliders, -50, 0, 0, 4, 8, 120, borderMat);
  addBox(objects, colliders, 50, 0, 0, 4, 8, 120, borderMat);

  // Procedural Pine Trees
  const treePositions = [
    [-35, -40], [-20, -45], [25, -42], [38, -35],
    [-40, -15], [-35, 5], [42, -5], [36, 15],
    [-25, 40], [-10, 45], [20, 42], [38, 40],
    [-15, -20], [18, -15], [-20, 20], [22, 25],
    [32, -18], [-32, -28], [0, -48], [0, 48]
  ];

  treePositions.forEach(([tx, tz]) => {
    // Trunk
    const trunkGeo = new THREE.CylinderGeometry(0.35, 0.5, 5.5, 8);
    const trunk = new THREE.Mesh(trunkGeo, barkMat);
    trunk.position.set(tx, 2.75, tz);
    trunk.castShadow = true;
    objects.push(trunk);

    colliders.push({
      minX: tx - 0.5,
      maxX: tx + 0.5,
      minZ: tz - 0.5,
      maxZ: tz + 0.5,
      minY: 0,
      maxY: 5,
    });

    // Tiered Pine Foliage cones
    for (let c = 0; c < 3; c++) {
      const coneGeo = new THREE.ConeGeometry(2.4 - c * 0.4, 2.5, 7);
      const cone = new THREE.Mesh(coneGeo, foliageMat);
      cone.position.set(tx, 4.5 + c * 1.5, tz);
      cone.castShadow = true;
      objects.push(cone);
    }
  });

  // Trench network:
  // Trenches are constructed with wooden duckboards, dirt berms, and sandbags
  // Main Central Trench (Z: -25 to 25, X: 0 to 4)
  const trenchH = 1.8;

  // Trench Walls / Parapets (Sandbags)
  const buildSandbagWall = (x: number, z: number, len: number, isHoriz: boolean) => {
    const w = isHoriz ? len : 0.8;
    const d = isHoriz ? 0.8 : len;
    addBox(objects, colliders, x, 0, z, w, trenchH, d, sandbagMat);
  };

  // Main vertical trench line
  buildSandbagWall(-2.5, 0, 50, false);
  buildSandbagWall(2.5, 0, 50, false);

  // Trench duckboard walkway in the middle
  const duckboard = new THREE.Mesh(new THREE.BoxGeometry(4.2, 0.1, 50), woodBoardMat);
  duckboard.position.set(0, 0.05, 0);
  objects.push(duckboard);

  // Zigzag transverse trench to Site A (East branch: X: 2.5 to 26, Z: -12)
  buildSandbagWall(14, -14, 24, true);
  buildSandbagWall(14, -10, 24, true);

  // Zigzag transverse trench to Site B (West branch: X: -2.5 to -26, Z: 10)
  buildSandbagWall(-14, 8, 24, true);
  buildSandbagWall(-14, 12, 24, true);

  // Bunker A (Reinforced concrete & wood bunker at X: 28, Z: -20)
  addBox(objects, colliders, 28, 0, -28, 14, 3.2, 1.5, dirtMat);
  addBox(objects, colliders, 28, 0, -12, 14, 3.2, 1.5, dirtMat);
  addBox(objects, colliders, 35, 0, -20, 1.5, 3.2, 16, dirtMat);
  // Bunker roof
  const bunkerRoof = new THREE.Mesh(new THREE.BoxGeometry(16, 0.8, 18), dirtMat);
  bunkerRoof.position.set(28, 3.2, -20);
  objects.push(bunkerRoof);

  // Site A Decal
  const decalA = new THREE.Mesh(new THREE.PlaneGeometry(4, 4), siteAMat);
  decalA.rotation.x = -Math.PI / 2;
  decalA.position.set(28, 0.1, -20);
  objects.push(decalA);

  // Bunker B (Outpost outpost at X: -28, Z: 20)
  addBox(objects, colliders, -28, 0, 12, 14, 3.2, 1.5, dirtMat);
  addBox(objects, colliders, -28, 0, 28, 14, 3.2, 1.5, dirtMat);
  addBox(objects, colliders, -35, 0, 20, 1.5, 3.2, 16, dirtMat);
  const bunkerBRoof = new THREE.Mesh(new THREE.BoxGeometry(16, 0.8, 18), dirtMat);
  bunkerBRoof.position.set(-28, 3.2, 20);
  objects.push(bunkerBRoof);

  // Site B Decal
  const decalB = new THREE.Mesh(new THREE.PlaneGeometry(4, 4), siteBMat);
  decalB.rotation.x = -Math.PI / 2;
  decalB.position.set(-28, 0.1, 20);
  objects.push(decalB);

  // Sandbag clusters and wooden crate ammunition boxes
  addBox(objects, colliders, 26, 0, -18, 2, 1.5, 2, sandbagMat);
  addBox(objects, colliders, -26, 0, 18, 2, 1.5, 2, sandbagMat);
  const crateTex = getProceduralTexture('wood_crate');
  const crateMat = new THREE.MeshStandardMaterial({ map: crateTex, roughness: 0.7 });
  addBox(objects, colliders, 0, 0, 0, 2, 1.8, 2, crateMat);
  addBox(objects, colliders, 18, 0, -11, 2, 1.8, 2, crateMat);
  addBox(objects, colliders, -18, 0, 9, 2, 1.8, 2, crateMat);

  return {
    name: 'trenches',
    displayName: 'de_trenches (Forest & Trenches)',
    objects,
    colliders,
    tSpawns: [
      new THREE.Vector3(0, 1.6, 44),
      new THREE.Vector3(-6, 1.6, 46),
      new THREE.Vector3(6, 1.6, 46),
      new THREE.Vector3(-12, 1.6, 44),
    ],
    ctSpawns: [
      new THREE.Vector3(0, 1.6, -44),
      new THREE.Vector3(8, 1.6, -46),
      new THREE.Vector3(-8, 1.6, -46),
      new THREE.Vector3(14, 1.6, -44),
    ],
    siteA: { center: new THREE.Vector3(28, 0.1, -20), radius: 6 },
    siteB: { center: new THREE.Vector3(-28, 0.1, 20), radius: 6 },
    patrolWaypoints: [
      new THREE.Vector3(0, 1.6, 35),
      new THREE.Vector3(0, 1.6, 10), // Main trench
      new THREE.Vector3(-14, 1.6, 10), // Branch to B
      new THREE.Vector3(-28, 1.6, 20), // Bunker B
      new THREE.Vector3(0, 1.6, -12), // Main trench mid
      new THREE.Vector3(14, 1.6, -12), // Branch to A
      new THREE.Vector3(28, 1.6, -20), // Bunker A
      new THREE.Vector3(0, 1.6, -35), // CT base
    ],
    skyColor: 0x5b6b7a,
    fogColor: 0x485663,
    fogDensity: 0.012, // atmospheric misty forest fog
    lightColor: 0xd9e5ef,
    lightIntensity: 1.1,
    groundType: 'grass',
  };
}

export function buildMap(mapName: 'dust2' | 'house' | 'trenches'): MapData {
  switch (mapName) {
    case 'house':
      return buildHouseMap();
    case 'trenches':
      return buildTrenchesMap();
    case 'dust2':
    default:
      return buildDust2Map();
  }
}
