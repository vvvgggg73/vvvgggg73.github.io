// Single-File HTML Generator: produces an all-in-one standalone HTML5 FPS game file
// that can be downloaded and opened in any browser without build tools or external assets.

export function generateStandaloneHtml(): string {
  return `<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <title>CS:GO 2 Three.js 3D FPS - Standalone Edition</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; user-select: none; }
    body, html { width: 100%; height: 100%; overflow: hidden; background: #0b0d10; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; color: #fff; }
    #canvas-container { position: absolute; inset: 0; width: 100%; height: 100%; }
    #hud { position: absolute; inset: 0; pointer-events: none; }
    
    /* Crosshair */
    #crosshair { position: absolute; top: 50%; left: 50%; width: 18px; height: 18px; transform: translate(-50%, -50%); }
    .ch-line { position: absolute; background: #00ff66; box-shadow: 0 0 2px #000; }
    .ch-t { top: 0; left: 8px; width: 2px; height: 6px; }
    .ch-b { bottom: 0; left: 8px; width: 2px; height: 6px; }
    .ch-l { top: 8px; left: 0; width: 6px; height: 2px; }
    .ch-r { top: 8px; right: 0; width: 6px; height: 2px; }
    .ch-dot { position: absolute; top: 8px; left: 8px; width: 2px; height: 2px; background: #00ff66; }

    /* Top Bar */
    .top-bar { position: absolute; top: 16px; left: 50%; transform: translateX(-50%); display: flex; align-items: center; gap: 16px; background: rgba(16,20,28,0.85); backdrop-filter: blur(8px); border: 1px solid rgba(255,255,255,0.1); padding: 8px 24px; border-radius: 8px; font-weight: bold; }
    .score-ct { color: #00d2ff; font-size: 24px; }
    .score-t { color: #ff8800; font-size: 24px; }
    .timer { font-size: 22px; min-width: 60px; text-align: center; }

    /* Bottom HUD */
    .bottom-hud { position: absolute; bottom: 20px; left: 24px; right: 24px; display: flex; justify-content: space-between; align-items: flex-end; }
    .hp-panel { background: rgba(16,20,28,0.85); padding: 12px 20px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.1); display: flex; gap: 24px; }
    .hp-val { font-size: 32px; font-weight: bold; color: #00ff66; }
    .armor-val { font-size: 32px; font-weight: bold; color: #00d2ff; }
    .ammo-panel { background: rgba(16,20,28,0.85); padding: 12px 24px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.1); text-align: right; }
    .ammo-val { font-size: 36px; font-weight: bold; color: #ffcc00; }
    .weapon-name { font-size: 14px; color: #aaa; text-transform: uppercase; }

    /* Start / Pause Overlay */
    #blocker { position: absolute; inset: 0; background: rgba(0,0,0,0.85); display: flex; flex-direction: column; align-items: center; justify-content: center; pointer-events: auto; }
    .btn { background: #ff8800; border: none; color: #000; font-weight: bold; font-size: 18px; padding: 14px 36px; border-radius: 6px; cursor: pointer; margin-top: 20px; }
    .btn:hover { background: #ffa533; }
  </style>
</head>
<body>
  <div id="canvas-container"></div>
  <div id="hud">
    <div id="crosshair">
      <div class="ch-line ch-t"></div>
      <div class="ch-line ch-b"></div>
      <div class="ch-line ch-l"></div>
      <div class="ch-line ch-r"></div>
      <div class="ch-dot"></div>
    </div>
    <div class="top-bar">
      <span class="score-ct" id="hud-score-ct">0</span>
      <span class="timer" id="hud-timer">01:55</span>
      <span class="score-t" id="hud-score-t">0</span>
    </div>
    <div class="bottom-hud">
      <div class="hp-panel">
        <div><div style="font-size: 11px; color:#888;">+ ЗДОРОВЬЕ</div><div class="hp-val" id="hud-hp">100</div></div>
        <div><div style="font-size: 11px; color:#888;">🛡 БРОНЯ</div><div class="armor-val" id="hud-armor">100</div></div>
      </div>
      <div class="ammo-panel">
        <div class="weapon-name" id="hud-weapon">AK-47</div>
        <div class="ammo-val"><span id="hud-ammo">30</span> <span style="font-size: 20px; color:#888;">/ <span id="hud-reserve">90</span></span></div>
      </div>
    </div>
  </div>

  <div id="blocker">
    <h1 style="font-size: 42px; margin-bottom: 10px; color: #ff8800;">COUNTER-STRIKE 2 3D FPS</h1>
    <p style="color: #aaa; margin-bottom: 24px;">Нажмите кнопку ниже или кликните по экрану для запуска</p>
    <div style="font-size: 14px; line-height: 1.8; color: #ddd; text-align: left; background: rgba(255,255,255,0.06); padding: 16px 24px; border-radius: 8px;">
      <b>WASD</b> — Движение | <b>Space</b> — Прыжок | <b>Shift</b> — Бег<br>
      <b>ЛКМ</b> — Огонь | <b>ПКМ</b> — Прицел (ADS Zoom) | <b>R</b> — Перезарядка<br>
      <b>1 / 2</b> — Смена оружия (AK-47 / Deagle) | <b>E</b> — Закладка/Разминирование
    </div>
    <button class="btn" id="start-btn">В БОЙ (START GAME)</button>
  </div>

  <script>
    // Audio engine using Web Audio API
    const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    function playShootSound(isRifle) {
      if (audioCtx.state === 'suspended') audioCtx.resume();
      const now = audioCtx.currentTime;
      const bSize = audioCtx.sampleRate * 0.25;
      const buf = audioCtx.createBuffer(1, bSize, audioCtx.sampleRate);
      const data = buf.getChannelData(0);
      for(let i=0; i<bSize; i++) data[i] = Math.random()*2 - 1;
      const src = audioCtx.createBufferSource();
      src.buffer = buf;
      const filter = audioCtx.createBiquadFilter();
      filter.frequency.setValueAtTime(3800, now);
      filter.frequency.exponentialRampToValueAtTime(100, now + 0.22);
      const gain = audioCtx.createGain();
      gain.gain.setValueAtTime(0.8, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.24);
      src.connect(filter); filter.connect(gain); gain.connect(audioCtx.destination);
      src.start(now);
    }

    // Three.js Scene Setup
    const container = document.getElementById('canvas-container');
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x90bfe8);
    scene.fog = new THREE.FogExp2(0xd4c2a5, 0.004);

    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 500);
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.shadowMap.enabled = true;
    container.appendChild(renderer.domElement);

    const hemiLight = new THREE.HemisphereLight(0xffffff, 0x444444, 0.7);
    scene.add(hemiLight);
    const dirLight = new THREE.DirectionalLight(0xfff3db, 1.2);
    dirLight.position.set(30, 60, 20);
    dirLight.castShadow = true;
    scene.add(dirLight);

    // Procedural sand ground
    const groundMat = new THREE.MeshStandardMaterial({ color: 0xd4b37f, roughness: 0.9 });
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(120, 120), groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);

    // Dust2 walls & crates
    const wallMat = new THREE.MeshStandardMaterial({ color: 0xba9663, roughness: 0.85 });
    const crateMat = new THREE.MeshStandardMaterial({ color: 0x825934, roughness: 0.7 });

    const colliders = [];
    function addBox(x, y, z, w, h, d, mat) {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
      mesh.position.set(x, y + h/2, z);
      mesh.castShadow = true; mesh.receiveShadow = true;
      scene.add(mesh);
      colliders.push({ minX: x-w/2, maxX: x+w/2, minZ: z-d/2, maxZ: z+d/2 });
      return mesh;
    }

    // Outer walls
    addBox(0, 0, -50, 100, 6, 2, wallMat);
    addBox(0, 0, 50, 100, 6, 2, wallMat);
    addBox(-50, 0, 0, 2, 6, 100, wallMat);
    addBox(50, 0, 0, 2, 6, 100, wallMat);

    // Inner dust2 layout
    addBox(15, 0, 0, 2, 6, 60, wallMat);
    addBox(-15, 0, 0, 2, 6, 60, wallMat);
    addBox(25, 0, -25, 16, 1.5, 16, wallMat); // Site A
    addBox(-25, 0, -25, 16, 1.5, 16, wallMat); // Site B
    addBox(22, 1.5, -23, 3, 3, 3, crateMat);
    addBox(-22, 1.5, -23, 3, 3, 3, crateMat);
    addBox(0, 0, 0, 4, 3, 4, crateMat);

    // Viewmodel Gun (AK-47)
    const gunGroup = new THREE.Group();
    const gunMat = new THREE.MeshStandardMaterial({ color: 0x222222, metalness: 0.8 });
    const woodMat = new THREE.MeshStandardMaterial({ color: 0x8a4b22 });
    const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.45), gunMat);
    barrel.rotation.x = Math.PI/2;
    barrel.position.set(0, 0.02, -0.4);
    gunGroup.add(barrel);
    const receiver = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.08, 0.35), gunMat);
    gunGroup.add(receiver);
    const stock = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.1, 0.28), woodMat);
    stock.position.set(0, -0.03, 0.28);
    gunGroup.add(stock);
    const mag = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.2, 0.08), woodMat);
    mag.position.set(0, -0.1, -0.05);
    mag.rotation.x = 0.3;
    gunGroup.add(mag);

    gunGroup.position.set(0.24, -0.25, -0.5);
    camera.add(gunGroup);
    scene.add(camera);

    // Player & Controls State
    let isLocked = false;
    let posX = 0, posY = 1.6, posZ = 35;
    let velX = 0, velY = 0, velZ = 0;
    let yaw = 0, pitch = 0;
    let hp = 100, armor = 100, ammo = 30, reserve = 90;
    let scoreCT = 0, scoreT = 0, roundTimer = 115;
    let isAiming = false;
    const keys = {};

    const blocker = document.getElementById('blocker');
    const startBtn = document.getElementById('start-btn');
    startBtn.addEventListener('click', () => {
      document.body.requestPointerLock();
    });
    document.addEventListener('pointerlockchange', () => {
      isLocked = document.pointerLockElement === document.body;
      blocker.style.display = isLocked ? 'none' : 'flex';
    });

    window.addEventListener('keydown', e => keys[e.code] = true);
    window.addEventListener('keyup', e => keys[e.code] = false);
    window.addEventListener('mousemove', e => {
      if (!isLocked) return;
      yaw -= e.movementX * 0.0022;
      pitch -= e.movementY * 0.0022;
      pitch = Math.max(-1.4, Math.min(1.4, pitch));
    });
    window.addEventListener('mousedown', e => {
      if (!isLocked) return;
      if (e.button === 0 && ammo > 0) {
        ammo--;
        playShootSound(true);
        gunGroup.position.z += 0.04;
        document.getElementById('hud-ammo').innerText = ammo;
      }
      if (e.button === 2) isAiming = true;
    });
    window.addEventListener('mouseup', e => {
      if (e.button === 2) isAiming = false;
    });
    window.addEventListener('contextmenu', e => e.preventDefault());

    // Loop
    let last = performance.now();
    function animate() {
      requestAnimationFrame(animate);
      const now = performance.now();
      const dt = Math.min(0.1, (now - last) / 1000);
      last = now;

      if (isLocked) {
        const speed = isAiming ? 3.0 : (keys['ShiftLeft'] ? 7.2 : 4.8);
        const fwd = new THREE.Vector3(-Math.sin(yaw), 0, -Math.cos(yaw));
        const rgt = new THREE.Vector3(Math.cos(yaw), 0, -Math.sin(yaw));
        const move = new THREE.Vector3();
        if (keys['KeyW']) move.add(fwd);
        if (keys['KeyS']) move.sub(fwd);
        if (keys['KeyD']) move.add(rgt);
        if (keys['KeyA']) move.sub(rgt);
        if (move.lengthSq() > 0) {
          move.normalize();
          velX = move.x * speed;
          velZ = move.z * speed;
        } else {
          velX *= 0.7; velZ *= 0.7;
        }

        posX += velX * dt;
        posZ += velZ * dt;
        camera.position.set(posX, posY, posZ);
        camera.rotation.set(0, 0, 0);
        camera.rotation.y = yaw;
        camera.rotation.x = pitch;

        const targetPos = isAiming ? new THREE.Vector3(0, -0.16, -0.4) : new THREE.Vector3(0.24, -0.25, -0.5);
        gunGroup.position.lerp(targetPos, dt * 10);
      }
      renderer.render(scene, camera);
    }
    animate();
  </script>
</body>
</html>`;
}
