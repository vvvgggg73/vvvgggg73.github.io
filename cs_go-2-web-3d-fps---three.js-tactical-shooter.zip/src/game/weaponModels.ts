import * as THREE from 'three';
import { getProceduralTexture } from './proceduralTextures';

export interface WeaponRig {
  group: THREE.Group;
  muzzlePos: THREE.Vector3;
  muzzleFlash: THREE.Mesh;
  muzzleLight: THREE.PointLight;
  boltMesh?: THREE.Mesh;
  defaultPosition: THREE.Vector3;
  aimPosition: THREE.Vector3;
  defaultRotation: THREE.Euler;
  aimRotation: THREE.Euler;
}

export function createRifleModel(): WeaponRig {
  const group = new THREE.Group();

  // Materials
  const metalMat = new THREE.MeshStandardMaterial({
    color: 0x222428,
    metalness: 0.85,
    roughness: 0.25,
  });

  const darkMetalMat = new THREE.MeshStandardMaterial({
    color: 0x111315,
    metalness: 0.9,
    roughness: 0.35,
  });

  const woodTexture = getProceduralTexture('wood_crate');
  const woodMat = new THREE.MeshStandardMaterial({
    map: woodTexture,
    roughness: 0.6,
    metalness: 0.05,
    color: 0xa05a2c,
  });

  // Main Receiver
  const receiverGeo = new THREE.BoxGeometry(0.06, 0.08, 0.42);
  const receiver = new THREE.Mesh(receiverGeo, metalMat);
  receiver.position.set(0, 0, 0);
  group.add(receiver);

  // Top Cover
  const coverGeo = new THREE.CylinderGeometry(0.03, 0.03, 0.35, 12, 1, false, 0, Math.PI);
  const cover = new THREE.Mesh(coverGeo, darkMetalMat);
  cover.rotation.x = Math.PI / 2;
  cover.position.set(0, 0.04, -0.02);
  group.add(cover);

  // Barrel
  const barrelGeo = new THREE.CylinderGeometry(0.015, 0.015, 0.45, 12);
  const barrel = new THREE.Mesh(barrelGeo, darkMetalMat);
  barrel.rotation.x = Math.PI / 2;
  barrel.position.set(0, 0.02, -0.42);
  group.add(barrel);

  // Gas Tube
  const gasTubeGeo = new THREE.CylinderGeometry(0.012, 0.012, 0.28, 8);
  const gasTube = new THREE.Mesh(gasTubeGeo, darkMetalMat);
  gasTube.rotation.x = Math.PI / 2;
  gasTube.position.set(0, 0.05, -0.34);
  group.add(gasTube);

  // Wooden Handguard (Lower & Upper)
  const handguardGeo = new THREE.BoxGeometry(0.065, 0.075, 0.24);
  const handguard = new THREE.Mesh(handguardGeo, woodMat);
  handguard.position.set(0, 0.03, -0.32);
  group.add(handguard);

  // Wooden Buttstock
  const stockGeo = new THREE.BoxGeometry(0.05, 0.11, 0.32);
  const stock = new THREE.Mesh(stockGeo, woodMat);
  stock.position.set(0, -0.03, 0.35);
  stock.rotation.x = 0.06;
  group.add(stock);

  // Pistol Grip
  const gripGeo = new THREE.BoxGeometry(0.045, 0.14, 0.065);
  const grip = new THREE.Mesh(gripGeo, woodMat);
  grip.position.set(0, -0.1, 0.08);
  grip.rotation.x = -0.35;
  group.add(grip);

  // Curved Banana Magazine
  const magGroup = new THREE.Group();
  const magGeo = new THREE.BoxGeometry(0.045, 0.22, 0.09);
  const magMat = new THREE.MeshStandardMaterial({
    color: 0xc45e22, // Iconic orange Bakelite magazine
    metalness: 0.2,
    roughness: 0.5,
  });
  const mag = new THREE.Mesh(magGeo, magMat);
  mag.position.set(0, -0.12, -0.06);
  mag.rotation.x = 0.28;
  magGroup.add(mag);
  group.add(magGroup);

  // Front Sight Post
  const frontSightGeo = new THREE.BoxGeometry(0.015, 0.05, 0.02);
  const frontSight = new THREE.Mesh(frontSightGeo, darkMetalMat);
  frontSight.position.set(0, 0.065, -0.58);
  group.add(frontSight);

  // Rear Sight Notch
  const rearSightGeo = new THREE.BoxGeometry(0.025, 0.03, 0.04);
  const rearSight = new THREE.Mesh(rearSightGeo, darkMetalMat);
  rearSight.position.set(0, 0.055, -0.18);
  group.add(rearSight);

  // Muzzle Flash Hider
  const flashHiderGeo = new THREE.CylinderGeometry(0.02, 0.02, 0.06, 8);
  const flashHider = new THREE.Mesh(flashHiderGeo, darkMetalMat);
  flashHider.rotation.x = Math.PI / 2;
  flashHider.position.set(0, 0.02, -0.66);
  group.add(flashHider);

  // Animated Bolt Handle
  const boltGeo = new THREE.BoxGeometry(0.04, 0.02, 0.03);
  const bolt = new THREE.Mesh(boltGeo, metalMat);
  bolt.position.set(0.04, 0.04, -0.04);
  group.add(bolt);

  // Muzzle Flash Geometry & Light
  const flashGeo = new THREE.OctahedronGeometry(0.12, 1);
  const flashMat = new THREE.MeshBasicMaterial({
    color: 0xffaa22,
    wireframe: false,
    transparent: true,
    opacity: 0,
  });
  const muzzleFlash = new THREE.Mesh(flashGeo, flashMat);
  muzzleFlash.position.set(0, 0.02, -0.76);
  group.add(muzzleFlash);

  const muzzleLight = new THREE.PointLight(0xff9900, 0, 10);
  muzzleLight.position.copy(muzzleFlash.position);
  group.add(muzzleLight);

  // Default Hipfire vs ADS Positions
  const defaultPosition = new THREE.Vector3(0.24, -0.25, -0.52);
  const aimPosition = new THREE.Vector3(0.0, -0.165, -0.42);
  const defaultRotation = new THREE.Euler(0.04, 0.03, -0.02);
  const aimRotation = new THREE.Euler(0.0, 0.0, 0.0);

  group.position.copy(defaultPosition);
  group.rotation.copy(defaultRotation);

  return {
    group,
    muzzlePos: new THREE.Vector3(0, 0.02, -0.76),
    muzzleFlash,
    muzzleLight,
    boltMesh: bolt,
    defaultPosition,
    aimPosition,
    defaultRotation,
    aimRotation,
  };
}

export function createPistolModel(): WeaponRig {
  const group = new THREE.Group();

  const chromeMat = new THREE.MeshStandardMaterial({
    color: 0xd8dde2,
    metalness: 0.95,
    roughness: 0.2,
  });

  const blackMat = new THREE.MeshStandardMaterial({
    color: 0x1a1a1c,
    metalness: 0.4,
    roughness: 0.6,
  });

  // Slide
  const slideGeo = new THREE.BoxGeometry(0.048, 0.06, 0.28);
  const slide = new THREE.Mesh(slideGeo, chromeMat);
  slide.position.set(0, 0.03, -0.02);
  group.add(slide);

  // Barrel opening
  const barrelGeo = new THREE.CylinderGeometry(0.016, 0.016, 0.04, 10);
  const barrel = new THREE.Mesh(barrelGeo, blackMat);
  barrel.rotation.x = Math.PI / 2;
  barrel.position.set(0, 0.03, -0.16);
  group.add(barrel);

  // Frame and grip
  const frameGeo = new THREE.BoxGeometry(0.044, 0.04, 0.24);
  const frame = new THREE.Mesh(frameGeo, blackMat);
  frame.position.set(0, -0.01, -0.02);
  group.add(frame);

  const gripGeo = new THREE.BoxGeometry(0.044, 0.14, 0.065);
  const grip = new THREE.Mesh(gripGeo, blackMat);
  grip.position.set(0, -0.09, 0.04);
  grip.rotation.x = -0.26;
  group.add(grip);

  // Sights
  const frontSightGeo = new THREE.BoxGeometry(0.01, 0.015, 0.02);
  const frontSight = new THREE.Mesh(frontSightGeo, blackMat);
  frontSight.position.set(0, 0.068, -0.15);
  group.add(frontSight);

  const rearSightGeo = new THREE.BoxGeometry(0.024, 0.015, 0.02);
  const rearSight = new THREE.Mesh(rearSightGeo, blackMat);
  rearSight.position.set(0, 0.068, 0.11);
  group.add(rearSight);

  // Muzzle flash
  const flashGeo = new THREE.OctahedronGeometry(0.09, 1);
  const flashMat = new THREE.MeshBasicMaterial({
    color: 0xffbb33,
    transparent: true,
    opacity: 0,
  });
  const muzzleFlash = new THREE.Mesh(flashGeo, flashMat);
  muzzleFlash.position.set(0, 0.03, -0.22);
  group.add(muzzleFlash);

  const muzzleLight = new THREE.PointLight(0xffaa11, 0, 8);
  muzzleLight.position.copy(muzzleFlash.position);
  group.add(muzzleLight);

  const defaultPosition = new THREE.Vector3(0.2, -0.22, -0.45);
  const aimPosition = new THREE.Vector3(0.0, -0.13, -0.38);
  const defaultRotation = new THREE.Euler(0.02, 0.02, 0.0);
  const aimRotation = new THREE.Euler(0.0, 0.0, 0.0);

  group.position.copy(defaultPosition);
  group.rotation.copy(defaultRotation);

  return {
    group,
    muzzlePos: new THREE.Vector3(0, 0.03, -0.22),
    muzzleFlash,
    muzzleLight,
    defaultPosition,
    aimPosition,
    defaultRotation,
    aimRotation,
  };
}

// 3D C4 Bomb Model for planting / defusing in world
export function createC4BombModel(): { group: THREE.Group; ledLight: THREE.PointLight; ledMesh: THREE.Mesh } {
  const group = new THREE.Group();

  // Semtex blocks
  const brickMat = new THREE.MeshStandardMaterial({
    color: 0x827052,
    roughness: 0.9,
  });

  const tapeMat = new THREE.MeshStandardMaterial({
    color: 0x333333,
    roughness: 0.4,
  });

  const block1 = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.1, 0.18), brickMat);
  group.add(block1);

  // Electrical duct tape
  const tape1 = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.105, 0.185), tapeMat);
  tape1.position.set(-0.08, 0, 0);
  group.add(tape1);
  const tape2 = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.105, 0.185), tapeMat);
  tape2.position.set(0.08, 0, 0);
  group.add(tape2);

  // Keypad & timer display
  const displayMat = new THREE.MeshBasicMaterial({ color: 0x111111 });
  const display = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.03, 0.12), displayMat);
  display.position.set(0, 0.06, 0);
  group.add(display);

  // LCD screen
  const screenMat = new THREE.MeshBasicMaterial({ color: 0x11ff22 });
  const screen = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.005, 0.03), screenMat);
  screen.position.set(0, 0.076, -0.03);
  group.add(screen);

  // Blinking red indicator LED
  const ledMat = new THREE.MeshBasicMaterial({ color: 0xff0000 });
  const ledMesh = new THREE.Mesh(new THREE.SphereGeometry(0.015, 8, 8), ledMat);
  ledMesh.position.set(0.04, 0.08, 0.03);
  group.add(ledMesh);

  const ledLight = new THREE.PointLight(0xff0000, 1.5, 4);
  ledLight.position.copy(ledMesh.position);
  group.add(ledLight);

  return { group, ledLight, ledMesh };
}
