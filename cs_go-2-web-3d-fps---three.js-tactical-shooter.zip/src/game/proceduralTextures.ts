import * as THREE from 'three';

// Cache generated textures so we don't recreate canvases unnecessarily
const textureCache = new Map<string, THREE.CanvasTexture>();

function createNoiseCanvas(width: number, height: number, drawFn: (ctx: CanvasRenderingContext2D, w: number, h: number) => void): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;
  drawFn(ctx, width, height);

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  return texture;
}

export function getProceduralTexture(name: string): THREE.CanvasTexture {
  if (textureCache.has(name)) {
    return textureCache.get(name)!;
  }

  let tex: THREE.CanvasTexture;

  switch (name) {
    case 'sandstone':
      tex = createNoiseCanvas(512, 512, (ctx, w, h) => {
        ctx.fillStyle = '#d4b37f';
        ctx.fillRect(0, 0, w, h);
        // Noise grains
        const img = ctx.getImageData(0, 0, w, h);
        const data = img.data;
        for (let i = 0; i < data.length; i += 4) {
          const n = (Math.random() - 0.5) * 45;
          data[i] = Math.min(255, Math.max(0, data[i] + n));
          data[i + 1] = Math.min(255, Math.max(0, data[i + 1] + n * 0.9));
          data[i + 2] = Math.min(255, Math.max(0, data[i + 2] + n * 0.7));
        }
        ctx.putImageData(img, 0, 0);

        // Brick mortar lines
        ctx.strokeStyle = 'rgba(120, 95, 60, 0.4)';
        ctx.lineWidth = 4;
        const rowH = 64;
        const brickW = 128;
        for (let y = 0; y < h; y += rowH) {
          ctx.beginPath();
          ctx.moveTo(0, y);
          ctx.lineTo(w, y);
          ctx.stroke();

          const offset = (y / rowH) % 2 === 0 ? 0 : brickW / 2;
          for (let x = offset; x < w; x += brickW) {
            ctx.beginPath();
            ctx.moveTo(x, y);
            ctx.lineTo(x, y + rowH);
            ctx.stroke();
          }
        }
      });
      break;

    case 'dust_ground':
      tex = createNoiseCanvas(512, 512, (ctx, w, h) => {
        ctx.fillStyle = '#caa574';
        ctx.fillRect(0, 0, w, h);
        const img = ctx.getImageData(0, 0, w, h);
        const data = img.data;
        for (let i = 0; i < data.length; i += 4) {
          const n = (Math.random() - 0.5) * 35;
          data[i] = Math.min(255, Math.max(0, data[i] + n));
          data[i + 1] = Math.min(255, Math.max(0, data[i + 1] + n * 0.9));
          data[i + 2] = Math.min(255, Math.max(0, data[i + 2] + n * 0.6));
        }
        ctx.putImageData(img, 0, 0);

        // Subtle paving stones
        ctx.strokeStyle = 'rgba(100, 80, 50, 0.2)';
        ctx.lineWidth = 3;
        for (let x = 0; x < w; x += 128) {
          ctx.strokeRect(x, 0, 128, h);
        }
      });
      break;

    case 'wood_crate':
      tex = createNoiseCanvas(512, 512, (ctx, w, h) => {
        ctx.fillStyle = '#8f6841';
        ctx.fillRect(0, 0, w, h);
        // Wood grain
        ctx.fillStyle = 'rgba(60, 35, 15, 0.15)';
        for (let y = 0; y < h; y += 16) {
          ctx.fillRect(0, y + (Math.random() * 4 - 2), w, 8);
        }
        // Border and cross beams
        ctx.fillStyle = '#5c3e21';
        ctx.fillRect(0, 0, w, 32);
        ctx.fillRect(0, h - 32, w, 32);
        ctx.fillRect(0, 0, 32, h);
        ctx.fillRect(w - 32, 0, 32, h);

        // Diagonal beam
        ctx.lineWidth = 28;
        ctx.strokeStyle = '#5c3e21';
        ctx.beginPath();
        ctx.moveTo(32, 32);
        ctx.lineTo(w - 32, h - 32);
        ctx.stroke();

        // Stencil
        ctx.fillStyle = 'rgba(255, 230, 160, 0.45)';
        ctx.font = 'bold 36px monospace';
        ctx.textAlign = 'center';
        ctx.fillText('CS2 CARGO', w / 2, h / 2 - 20);
        ctx.font = 'bold 22px monospace';
        ctx.fillText('HANDLE WITH CARE', w / 2, h / 2 + 25);
      });
      break;

    case 'metal_container':
      tex = createNoiseCanvas(512, 512, (ctx, w, h) => {
        ctx.fillStyle = '#3a5f78';
        ctx.fillRect(0, 0, w, h);
        // Corrugation ridges
        for (let x = 0; x < w; x += 32) {
          const grad = ctx.createLinearGradient(x, 0, x + 32, 0);
          grad.addColorStop(0, 'rgba(255,255,255,0.18)');
          grad.addColorStop(0.5, 'rgba(0,0,0,0)');
          grad.addColorStop(1, 'rgba(0,0,0,0.3)');
          ctx.fillStyle = grad;
          ctx.fillRect(x, 0, 32, h);
        }
        // Rust spots
        ctx.fillStyle = 'rgba(160, 80, 30, 0.4)';
        for (let i = 0; i < 8; i++) {
          ctx.beginPath();
          ctx.arc(Math.random() * w, Math.random() * h, 10 + Math.random() * 20, 0, Math.PI * 2);
          ctx.fill();
        }
      });
      break;

    case 'concrete':
      tex = createNoiseCanvas(512, 512, (ctx, w, h) => {
        ctx.fillStyle = '#82868a';
        ctx.fillRect(0, 0, w, h);
        const img = ctx.getImageData(0, 0, w, h);
        const data = img.data;
        for (let i = 0; i < data.length; i += 4) {
          const n = (Math.random() - 0.5) * 40;
          data[i] = Math.min(255, Math.max(0, data[i] + n));
          data[i + 1] = Math.min(255, Math.max(0, data[i + 1] + n));
          data[i + 2] = Math.min(255, Math.max(0, data[i + 2] + n));
        }
        ctx.putImageData(img, 0, 0);
      });
      break;

    case 'wood_floor':
      tex = createNoiseCanvas(512, 512, (ctx, w, h) => {
        ctx.fillStyle = '#6a4727';
        ctx.fillRect(0, 0, w, h);
        const plankH = 40;
        ctx.strokeStyle = '#321f0e';
        ctx.lineWidth = 3;
        for (let y = 0; y < h; y += plankH) {
          ctx.fillStyle = y % (plankH * 2) === 0 ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.08)';
          ctx.fillRect(0, y, w, plankH);
          ctx.strokeRect(0, y, w, plankH);
          for (let x = (y % 80); x < w; x += 160) {
            ctx.beginPath();
            ctx.moveTo(x, y);
            ctx.lineTo(x, y + plankH);
            ctx.stroke();
          }
        }
      });
      break;

    case 'wallpaper':
      tex = createNoiseCanvas(512, 512, (ctx, w, h) => {
        ctx.fillStyle = '#39424e';
        ctx.fillRect(0, 0, w, h);
        ctx.fillStyle = '#4a5463';
        const step = 64;
        for (let x = 0; x < w; x += step) {
          for (let y = 0; y < h; y += step) {
            ctx.beginPath();
            ctx.arc(x + step / 2, y + step / 2, 12, 0, Math.PI * 2);
            ctx.fill();
          }
        }
      });
      break;

    case 'grass':
      tex = createNoiseCanvas(512, 512, (ctx, w, h) => {
        ctx.fillStyle = '#35532b';
        ctx.fillRect(0, 0, w, h);
        const img = ctx.getImageData(0, 0, w, h);
        const data = img.data;
        for (let i = 0; i < data.length; i += 4) {
          const n = (Math.random() - 0.5) * 50;
          data[i] = Math.min(255, Math.max(0, data[i] + n * 0.7));
          data[i + 1] = Math.min(255, Math.max(0, data[i + 1] + n));
          data[i + 2] = Math.min(255, Math.max(0, data[i + 2] + n * 0.5));
        }
        ctx.putImageData(img, 0, 0);

        // Grass specks
        ctx.fillStyle = '#4c783e';
        for (let i = 0; i < 300; i++) {
          ctx.fillRect(Math.random() * w, Math.random() * h, 3, 7);
        }
      });
      break;

    case 'dirt_trench':
      tex = createNoiseCanvas(512, 512, (ctx, w, h) => {
        ctx.fillStyle = '#4b392b';
        ctx.fillRect(0, 0, w, h);
        const img = ctx.getImageData(0, 0, w, h);
        const data = img.data;
        for (let i = 0; i < data.length; i += 4) {
          const n = (Math.random() - 0.5) * 50;
          data[i] = Math.min(255, Math.max(0, data[i] + n));
          data[i + 1] = Math.min(255, Math.max(0, data[i + 1] + n * 0.8));
          data[i + 2] = Math.min(255, Math.max(0, data[i + 2] + n * 0.6));
        }
        ctx.putImageData(img, 0, 0);

        // Small pebbles
        ctx.fillStyle = '#7a6756';
        for (let i = 0; i < 60; i++) {
          ctx.beginPath();
          ctx.arc(Math.random() * w, Math.random() * h, 3 + Math.random() * 5, 0, Math.PI * 2);
          ctx.fill();
        }
      });
      break;

    case 'tree_bark':
      tex = createNoiseCanvas(256, 512, (ctx, w, h) => {
        ctx.fillStyle = '#3c2918';
        ctx.fillRect(0, 0, w, h);
        ctx.fillStyle = '#22150a';
        for (let x = 0; x < w; x += 18) {
          ctx.fillRect(x, 0, 6 + Math.random() * 6, h);
        }
        ctx.fillStyle = '#523a24';
        for (let i = 0; i < 40; i++) {
          ctx.fillRect(Math.random() * w, Math.random() * h, 12, 30);
        }
      });
      break;

    case 'site_a':
      tex = createNoiseCanvas(256, 256, (ctx, w, h) => {
        ctx.fillStyle = '#e63946';
        ctx.beginPath();
        ctx.arc(w / 2, h / 2, 100, 0, Math.PI * 2);
        ctx.fill();
        ctx.lineWidth = 12;
        ctx.strokeStyle = '#ffffff';
        ctx.stroke();

        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 120px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('A', w / 2, h / 2 + 5);
      });
      break;

    case 'site_b':
      tex = createNoiseCanvas(256, 256, (ctx, w, h) => {
        ctx.fillStyle = '#f4a261';
        ctx.beginPath();
        ctx.arc(w / 2, h / 2, 100, 0, Math.PI * 2);
        ctx.fill();
        ctx.lineWidth = 12;
        ctx.strokeStyle = '#ffffff';
        ctx.stroke();

        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 120px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('B', w / 2, h / 2 + 5);
      });
      break;

    default:
      tex = createNoiseCanvas(256, 256, (ctx, w, h) => {
        ctx.fillStyle = '#888888';
        ctx.fillRect(0, 0, w, h);
      });
      break;
  }

  textureCache.set(name, tex);
  return tex;
}
