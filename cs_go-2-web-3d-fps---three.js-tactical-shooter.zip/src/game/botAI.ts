import * as THREE from 'three';
import { BoundingBox2D } from './mapBuilder';

export type Team = 'T' | 'CT';

export interface BotState {
  id: string;
  name: string;
  team: Team;
  hp: number;
  maxHp: number;
  position: THREE.Vector3;
  rotation: THREE.Euler;
  isAlive: boolean;
  kills: number;
  deaths: number;
  score: number;
  ping: number;
  model: THREE.Group;
  currentWaypointIdx: number;
  targetEnemy: { position: THREE.Vector3; isPlayer: boolean; ref?: BotState } | null;
  shootCooldown: number;
  burstCount: number;
  burstMax: number;
  actionTimer: number;
  deathAnimTimer: number;
  carryingBomb: boolean;
  isPlanting: boolean;
  isDefusing: boolean;
  actionProgress: number; // 0 to 1
}

// Check 2D AABB collision against colliders
export function checkCollision(pos: THREE.Vector3, radius: number, colliders: BoundingBox2D[]): boolean {
  for (const c of colliders) {
    if (
      pos.x + radius > c.minX &&
      pos.x - radius < c.maxX &&
      pos.z + radius > c.minZ &&
      pos.z - radius < c.maxZ &&
      pos.y >= c.minY &&
      pos.y <= c.maxY + 1.8
    ) {
      return true;
    }
  }
  return false;
}

// Raycast against box colliders for vision occlusion
export function hasLineOfSight(
  from: THREE.Vector3,
  to: THREE.Vector3,
  colliders: BoundingBox2D[]
): boolean {
  const dir = new THREE.Vector3().subVectors(to, from);
  const dist = dir.length();
  dir.normalize();

  // Step ray in small increments
  const step = 0.8;
  const curr = from.clone();
  for (let d = step; d < dist - 0.5; d += step) {
    curr.addScaledVector(dir, step);
    for (const c of colliders) {
      if (
        curr.x >= c.minX &&
        curr.x <= c.maxX &&
        curr.z >= c.minZ &&
        curr.z <= c.maxZ &&
        curr.y >= c.minY &&
        curr.y <= c.maxY
      ) {
        return false; // occluded by wall
      }
    }
  }
  return true;
}

export function createPlayerMesh(team: Team): THREE.Group {
  const group = new THREE.Group();

  // Colors based on team
  const torsoColor = team === 'CT' ? 0x223a5e : 0x6e4e37; // CT dark blue tactical / T olive-brown
  const vestColor = team === 'CT' ? 0x141e2e : 0x42382c;
  const pantsColor = team === 'CT' ? 0x1c2b3d : 0x3d392f;
  const helmetColor = team === 'CT' ? 0x1e2733 : 0x1b1b1b; // CT helmet / T balaclava

  const skinMat = new THREE.MeshStandardMaterial({ color: 0xd9a584, roughness: 0.7 });
  const vestMat = new THREE.MeshStandardMaterial({ color: vestColor, roughness: 0.6 });
  const torsoMat = new THREE.MeshStandardMaterial({ color: torsoColor, roughness: 0.7 });
  const pantsMat = new THREE.MeshStandardMaterial({ color: pantsColor, roughness: 0.8 });
  const helmetMat = new THREE.MeshStandardMaterial({ color: helmetColor, roughness: 0.5 });
  const bootMat = new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.4 });
  const gunMat = new THREE.MeshStandardMaterial({ color: 0x222222, metalness: 0.8, roughness: 0.3 });

  // Torso / Chest
  const torsoGeo = new THREE.BoxGeometry(0.5, 0.65, 0.28);
  const torso = new THREE.Mesh(torsoGeo, torsoMat);
  torso.position.y = 1.05;
  torso.castShadow = true;
  group.add(torso);

  // Tactical Vest
  const vestGeo = new THREE.BoxGeometry(0.54, 0.48, 0.32);
  const vest = new THREE.Mesh(vestGeo, vestMat);
  vest.position.y = 1.08;
  group.add(vest);

  // Head
  const headGeo = new THREE.BoxGeometry(0.24, 0.26, 0.24);
  const head = new THREE.Mesh(headGeo, skinMat);
  head.position.y = 1.55;
  head.castShadow = true;
  group.add(head);

  // Helmet / Mask
  if (team === 'CT') {
    // CT Helmet & Visor
    const helmetGeo = new THREE.BoxGeometry(0.28, 0.16, 0.28);
    const helmet = new THREE.Mesh(helmetGeo, helmetMat);
    helmet.position.set(0, 1.65, 0);
    group.add(helmet);

    // Goggles
    const goggleMat = new THREE.MeshBasicMaterial({ color: 0x00d2ff });
    const goggles = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.06, 0.08), goggleMat);
    goggles.position.set(0, 1.58, 0.12);
    group.add(goggles);
  } else {
    // T Balaclava Mask
    const maskGeo = new THREE.BoxGeometry(0.26, 0.24, 0.26);
    const mask = new THREE.Mesh(maskGeo, helmetMat);
    mask.position.set(0, 1.56, 0);
    group.add(mask);

    // Eye slits
    const eyeMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const eyeR = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.02, 0.02), eyeMat);
    eyeR.position.set(0.06, 1.58, 0.135);
    group.add(eyeR);
    const eyeL = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.02, 0.02), eyeMat);
    eyeL.position.set(-0.06, 1.58, 0.135);
    group.add(eyeL);
  }

  // Left & Right Legs
  const legGeo = new THREE.BoxGeometry(0.2, 0.7, 0.2);
  const legL = new THREE.Mesh(legGeo, pantsMat);
  legL.position.set(-0.14, 0.38, 0);
  legL.name = 'legL';
  group.add(legL);

  const legR = new THREE.Mesh(legGeo, pantsMat);
  legR.position.set(0.14, 0.38, 0);
  legR.name = 'legR';
  group.add(legR);

  // Boots
  const bootGeo = new THREE.BoxGeometry(0.21, 0.16, 0.26);
  const bootL = new THREE.Mesh(bootGeo, bootMat);
  bootL.position.set(-0.14, 0.08, 0.02);
  group.add(bootL);
  const bootR = new THREE.Mesh(bootGeo, bootMat);
  bootR.position.set(0.14, 0.08, 0.02);
  group.add(bootR);

  // Arms holding weapon
  const armGeo = new THREE.BoxGeometry(0.14, 0.55, 0.14);
  const armL = new THREE.Mesh(armGeo, torsoMat);
  armL.position.set(-0.32, 1.05, 0.1);
  armL.rotation.x = -Math.PI / 4;
  group.add(armL);

  const armR = new THREE.Mesh(armGeo, torsoMat);
  armR.position.set(0.32, 1.05, 0.1);
  armR.rotation.x = -Math.PI / 3;
  group.add(armR);

  // 3D Gun model in bot hands
  const botGunGeo = new THREE.BoxGeometry(0.08, 0.1, 0.6);
  const botGun = new THREE.Mesh(botGunGeo, gunMat);
  botGun.position.set(0.15, 1.0, 0.35);
  group.add(botGun);

  // Health indicator overhead (small bar)
  const hpBarBg = new THREE.Mesh(
    new THREE.PlaneGeometry(0.7, 0.08),
    new THREE.MeshBasicMaterial({ color: 0x222222, side: THREE.DoubleSide })
  );
  hpBarBg.position.set(0, 1.95, 0);
  hpBarBg.name = 'hpBarBg';
  group.add(hpBarBg);

  const hpBarFill = new THREE.Mesh(
    new THREE.PlaneGeometry(0.68, 0.06),
    new THREE.MeshBasicMaterial({
      color: team === 'CT' ? 0x00e5ff : 0xff7700,
      side: THREE.DoubleSide,
    })
  );
  hpBarFill.position.set(0, 1.95, 0.005);
  hpBarFill.name = 'hpBarFill';
  group.add(hpBarFill);

  return group;
}

export function initBots(playerTeam: Team, waypoints: THREE.Vector3[]): BotState[] {
  const bots: BotState[] = [];

  const tNames = ['Bot Yuri', 'Bot Phoenix', 'Bot Viktor', 'Bot Boris'];
  const ctNames = ['Bot SAS', 'Bot Seal', 'Bot GIGN', 'Bot GSG9'];

  // Total 6 bots: 3 on T, 3 on CT (since player fills 1 slot on playerTeam)
  const tCount = playerTeam === 'T' ? 3 : 3;
  const ctCount = playerTeam === 'CT' ? 3 : 3;

  // Create T Bots
  for (let i = 0; i < tCount; i++) {
    const mesh = createPlayerMesh('T');
    bots.push({
      id: `bot_t_${i}`,
      name: tNames[i % tNames.length],
      team: 'T',
      hp: 100,
      maxHp: 100,
      position: new THREE.Vector3(0, 0, 0),
      rotation: new THREE.Euler(),
      isAlive: true,
      kills: 0,
      deaths: 0,
      score: 0,
      ping: Math.floor(15 + Math.random() * 35),
      model: mesh,
      currentWaypointIdx: Math.floor(Math.random() * waypoints.length),
      targetEnemy: null,
      shootCooldown: 0.3 + Math.random() * 0.4,
      burstCount: 0,
      burstMax: 3 + Math.floor(Math.random() * 3),
      actionTimer: 0,
      deathAnimTimer: 0,
      carryingBomb: i === 0 && playerTeam !== 'T', // Give bomb to first T bot if player isn't T
      isPlanting: false,
      isDefusing: false,
      actionProgress: 0,
    });
  }

  // Create CT Bots
  for (let i = 0; i < ctCount; i++) {
    const mesh = createPlayerMesh('CT');
    bots.push({
      id: `bot_ct_${i}`,
      name: ctNames[i % ctNames.length],
      team: 'CT',
      hp: 100,
      maxHp: 100,
      position: new THREE.Vector3(0, 0, 0),
      rotation: new THREE.Euler(),
      isAlive: true,
      kills: 0,
      deaths: 0,
      score: 0,
      ping: Math.floor(15 + Math.random() * 35),
      model: mesh,
      currentWaypointIdx: Math.floor(Math.random() * waypoints.length),
      targetEnemy: null,
      shootCooldown: 0.3 + Math.random() * 0.4,
      burstCount: 0,
      burstMax: 3 + Math.floor(Math.random() * 3),
      actionTimer: 0,
      deathAnimTimer: 0,
      carryingBomb: false,
      isPlanting: false,
      isDefusing: false,
      actionProgress: 0,
    });
  }

  return bots;
}
