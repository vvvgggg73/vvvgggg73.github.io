import {
  Crosshair,
  Download,
  Flame,
  Gamepad2,
  Maximize2,
  Play,
  RotateCcw,
  Shield,
  Skull,
  Timer,
  Volume2,
  VolumeX,
} from 'lucide-react';
import React, { useEffect, useRef, useState } from 'react';
import { audio } from './game/audio';
import { GameEngine, GameMode, HUDState } from './game/gameEngine';
import { generateStandaloneHtml } from './game/standaloneHtmlGenerator';

export default function App() {
  const containerRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<GameEngine | null>(null);

  // Game Settings State
  const [selectedMap, setSelectedMap] = useState<'dust2' | 'house' | 'trenches'>('dust2');
  const [gameMode, setGameMode] = useState<GameMode>('defusal');
  const [team, setTeam] = useState<'CT' | 'T'>('CT');
  const [isMuted, setIsMuted] = useState(false);
  const [isGameStarted, setIsGameStarted] = useState(false);
  const [showScoreboard, setShowScoreboard] = useState(false);
  const [showSettings, setShowSettings] = useState(false);

  // HUD State synced from GameEngine
  const [hud, setHud] = useState<HUDState>({
    hp: 100,
    armor: 100,
    ammo: 30,
    reserveAmmo: 90,
    weaponName: 'AK-47',
    isReloading: false,
    isAiming: false,
    team: 'CT',
    scoreT: 0,
    scoreCT: 0,
    roundTimer: 115,
    gameMode: 'defusal',
    mapName: 'de_dust2 (Dust 2)',
    bombState: { status: 'carried', timer: 40 },
    interactPrompt: null,
    interactProgress: 0,
    hitmarker: false,
    isHeadshot: false,
    damageVignette: false,
    isGameOver: false,
    roundWinner: null,
    winReason: '',
    killfeed: [],
    scoreboard: [],
    minimapData: {
      playerPos: { x: 0, z: 0 },
      playerAngle: 0,
      siteA: { x: 30, z: -35 },
      siteB: { x: -30, z: -35 },
      bombPos: null,
      entities: [],
    },
  });

  // Initialize Game Engine on mount
  useEffect(() => {
    if (!containerRef.current) return;

    const engine = new GameEngine(
      containerRef.current,
      selectedMap,
      gameMode,
      team,
      (newHud) => {
        setHud(newHud);
      }
    );
    engineRef.current = engine;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Tab') {
        e.preventDefault();
        setShowScoreboard(true);
      }
      if (e.code === 'Escape') {
        setShowSettings(prev => !prev);
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.code === 'Tab') {
        e.preventDefault();
        setShowScoreboard(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      engine.destroy();
    };
  }, []);

  // Handle map change
  const handleMapChange = (mapName: 'dust2' | 'house' | 'trenches') => {
    setSelectedMap(mapName);
    if (engineRef.current) {
      engineRef.current.changeMap(mapName);
    }
  };

  // Handle mode change
  const handleModeChange = (mode: GameMode) => {
    setGameMode(mode);
    if (engineRef.current) {
      engineRef.current.changeGameMode(mode);
    }
  };

  // Handle team change
  const handleTeamChange = (newTeam: 'CT' | 'T') => {
    setTeam(newTeam);
    if (engineRef.current) {
      engineRef.current.changeTeam(newTeam);
    }
  };

  // Audio mute toggle
  const toggleMute = () => {
    const next = !isMuted;
    setIsMuted(next);
    audio.setMuted(next);
  };

  // Start / Lock game
  const handleStartGame = () => {
    setIsGameStarted(true);
    setShowSettings(false);
    if (engineRef.current) {
      engineRef.current.requestLock();
    }
  };

  // Download Standalone HTML file
  const handleDownloadStandalone = () => {
    const htmlContent = generateStandaloneHtml();
    const blob = new Blob([htmlContent], { type: 'text/html;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'csgo2_threejs_shooter.html';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Format seconds to mm:ss
  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="relative w-full h-screen overflow-hidden bg-neutral-950 font-['Rajdhani',sans-serif] select-none text-white">
      {/* 3D WebGL Canvas Container */}
      <div ref={containerRef} className="absolute inset-0 w-full h-full cursor-crosshair" />

      {/* Red Damage Vignette Screen Flash */}
      <div
        className={`pointer-events-none absolute inset-0 transition-opacity duration-150 ${
          hud.damageVignette ? 'opacity-80' : 'opacity-0'
        }`}
        style={{
          boxShadow: 'inset 0 0 120px 40px rgba(220, 20, 20, 0.8)',
          background: 'radial-gradient(circle, transparent 40%, rgba(200, 0, 0, 0.4) 100%)',
        }}
      />

      {/* --- CS:GO 2 HUD OVERLAY --- */}
      <div className="pointer-events-none absolute inset-0">
        {/* Dynamic Crosshair */}
        <div
          className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 transition-transform duration-75 ${
            hud.isAiming ? 'scale-75 opacity-90' : 'scale-100 opacity-100'
          }`}
        >
          {/* Crosshair ticks */}
          <div className="relative w-7 h-7 flex items-center justify-center">
            {/* Center dot */}
            <div className="w-1 h-1 bg-[#00ff66] rounded-full shadow-[0_0_4px_#00ff66]" />
            {/* Top tick */}
            <div className="absolute top-0 w-0.5 h-2 bg-[#00ff66] shadow-[0_0_3px_#000]" />
            {/* Bottom tick */}
            <div className="absolute bottom-0 w-0.5 h-2 bg-[#00ff66] shadow-[0_0_3px_#000]" />
            {/* Left tick */}
            <div className="absolute left-0 h-0.5 w-2 bg-[#00ff66] shadow-[0_0_3px_#000]" />
            {/* Right tick */}
            <div className="absolute right-0 h-0.5 w-2 bg-[#00ff66] shadow-[0_0_3px_#000]" />
          </div>

          {/* Hitmarker Feedback */}
          {hud.hitmarker && (
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 pointer-events-none">
              <div
                className={`absolute inset-0 border-2 rounded-sm rotate-45 animate-ping opacity-75 ${
                  hud.isHeadshot ? 'border-red-500 shadow-[0_0_12px_red]' : 'border-red-400'
                }`}
              />
              {hud.isHeadshot && (
                <div className="absolute -top-6 left-1/2 -translate-x-1/2 text-xs font-bold tracking-widest text-red-500 uppercase whitespace-nowrap drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]">
                  ★ HEADSHOT ★
                </div>
              )}
            </div>
          )}
        </div>

        {/* --- TOP BAR: CS2 SCORE & ROUND STATUS --- */}
        <div className="absolute top-4 left-1/2 -translate-x-1/2 flex items-center gap-3">
          {/* Counter-Terrorists Side (Left) */}
          <div className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-sky-950/80 to-slate-900/90 border border-sky-500/30 rounded-l-lg backdrop-blur-md shadow-lg shadow-sky-950/30">
            <span className="text-xs font-bold tracking-widest text-sky-400 uppercase">CT СПЕЦНАЗ</span>
            <div className="text-3xl font-black font-['Chakra_Petch'] text-sky-400 min-w-8 text-center drop-shadow-[0_0_8px_rgba(56,189,248,0.5)]">
              {hud.scoreCT}
            </div>
            {/* Alive CT icons */}
            <div className="flex gap-1">
              {[...Array(3)].map((_, i) => (
                <div
                  key={i}
                  className={`w-3.5 h-3.5 rounded-sm flex items-center justify-center text-[10px] ${
                    i === 0 && hud.team === 'CT' && hud.hp <= 0 ? 'bg-neutral-800 text-neutral-600' : 'bg-sky-500/30 text-sky-300'
                  }`}
                >
                  ▲
                </div>
              ))}
            </div>
          </div>

          {/* Central Round Timer / Bomb Status */}
          <div className="px-5 py-2.5 bg-neutral-900/90 border border-neutral-700/60 rounded-md backdrop-blur-md shadow-xl flex flex-col items-center min-w-28">
            {hud.bombState.status === 'planted' ? (
              <div className="flex flex-col items-center">
                <div className="flex items-center gap-1.5 text-orange-500 font-bold text-xs tracking-wider animate-pulse">
                  <Flame className="w-3.5 h-3.5 text-orange-500" /> C4 ЗАЛОЖЕНА ({hud.bombState.site || 'A'})
                </div>
                <div className="text-2xl font-black font-['Chakra_Petch'] text-red-500">
                  {hud.bombState.timer.toFixed(1)}s
                </div>
              </div>
            ) : (
              <>
                <div className="flex items-center gap-1 text-[11px] font-bold text-neutral-400 uppercase tracking-widest">
                  <Timer className="w-3 h-3 text-neutral-400" /> РАУНД
                </div>
                <div className="text-2xl font-black font-['Chakra_Petch'] text-neutral-100 tracking-wider">
                  {formatTime(hud.roundTimer)}
                </div>
              </>
            )}
          </div>

          {/* Terrorists Side (Right) */}
          <div className="flex items-center gap-2 px-4 py-2 bg-gradient-to-l from-amber-950/80 to-slate-900/90 border border-amber-500/30 rounded-r-lg backdrop-blur-md shadow-lg shadow-amber-950/30">
            <div className="flex gap-1">
              {[...Array(3)].map((_, i) => (
                <div
                  key={i}
                  className={`w-3.5 h-3.5 rounded-sm flex items-center justify-center text-[10px] ${
                    i === 0 && hud.team === 'T' && hud.hp <= 0 ? 'bg-neutral-800 text-neutral-600' : 'bg-amber-500/30 text-amber-400'
                  }`}
                >
                  ▼
                </div>
              ))}
            </div>
            <div className="text-3xl font-black font-['Chakra_Petch'] text-amber-400 min-w-8 text-center drop-shadow-[0_0_8px_rgba(251,191,36,0.5)]">
              {hud.scoreT}
            </div>
            <span className="text-xs font-bold tracking-widest text-amber-400 uppercase">Т ТЕРРОРИСТЫ</span>
          </div>
        </div>

        {/* --- TOP LEFT: TACTICAL RADAR / MINIMAP --- */}
        <div className="absolute top-4 left-4 p-2 bg-neutral-950/85 border border-neutral-700/50 rounded-xl backdrop-blur-md shadow-2xl flex flex-col items-center">
          <div className="text-[10px] font-bold tracking-widest text-neutral-400 uppercase mb-1">
            РАДАР • {hud.mapName.split(' ')[0]}
          </div>
          <div className="relative w-36 h-36 rounded-lg bg-neutral-900/95 overflow-hidden border border-neutral-800 flex items-center justify-center">
            {/* Grid concentric rings */}
            <div className="absolute inset-2 border border-neutral-700/30 rounded-full" />
            <div className="absolute inset-8 border border-neutral-700/40 rounded-full" />
            <div className="absolute w-full h-[1px] bg-neutral-800" />
            <div className="absolute h-full w-[1px] bg-neutral-800" />

            {/* Radar scanner sweep effect */}
            <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-cyan-500/5 to-cyan-500/20 rounded-full animate-spin [animation-duration:4s]" />

            {/* Site A Indicator */}
            {hud.minimapData && (
              <>
                <div
                  className="absolute w-4 h-4 rounded-full bg-red-600/80 text-[9px] font-black flex items-center justify-center text-white border border-white/40 shadow-sm"
                  style={{
                    left: `${Math.max(10, Math.min(125, 72 + (hud.minimapData.siteA.x - hud.minimapData.playerPos.x) * 1.4))}px`,
                    top: `${Math.max(10, Math.min(125, 72 + (hud.minimapData.siteA.z - hud.minimapData.playerPos.z) * 1.4))}px`,
                  }}
                >
                  A
                </div>
                {/* Site B Indicator */}
                <div
                  className="absolute w-4 h-4 rounded-full bg-amber-600/80 text-[9px] font-black flex items-center justify-center text-white border border-white/40 shadow-sm"
                  style={{
                    left: `${Math.max(10, Math.min(125, 72 + (hud.minimapData.siteB.x - hud.minimapData.playerPos.x) * 1.4))}px`,
                    top: `${Math.max(10, Math.min(125, 72 + (hud.minimapData.siteB.z - hud.minimapData.playerPos.z) * 1.4))}px`,
                  }}
                >
                  B
                </div>
              </>
            )}

            {/* Bot entities on radar */}
            {hud.minimapData?.entities.map((ent, i) => {
              if (!ent.isAlive) return null;
              const relX = (ent.x - hud.minimapData.playerPos.x) * 1.4;
              const relZ = (ent.z - hud.minimapData.playerPos.z) * 1.4;
              if (Math.hypot(relX, relZ) > 60) return null; // out of radar bounds
              return (
                <div
                  key={i}
                  className={`absolute w-2 h-2 rounded-full border border-black/50 ${
                    ent.team === hud.team
                      ? 'bg-sky-400'
                      : ent.isSpotted
                      ? 'bg-red-500 animate-pulse'
                      : 'hidden'
                  }`}
                  style={{
                    left: `${72 + relX - 4}px`,
                    top: `${72 + relZ - 4}px`,
                  }}
                />
              );
            })}

            {/* Planted bomb on radar */}
            {hud.minimapData?.bombPos && (
              <div
                className="absolute w-3 h-3 rounded-full bg-orange-500 border border-white animate-ping"
                style={{
                  left: `${72 + (hud.minimapData.bombPos.x - hud.minimapData.playerPos.x) * 1.4 - 6}px`,
                  top: `${72 + (hud.minimapData.bombPos.z - hud.minimapData.playerPos.z) * 1.4 - 6}px`,
                }}
              />
            )}

            {/* Player position center icon (green arrow pointing yaw) */}
            <div
              className="absolute w-3 h-3 text-[#00ff66] flex items-center justify-center font-bold text-xs"
              style={{
                transform: `rotate(${-hud.minimapData.playerAngle}rad)`,
              }}
            >
              ▲
            </div>
          </div>
        </div>

        {/* --- TOP RIGHT: KILLFEED --- */}
        <div className="absolute top-4 right-4 flex flex-col gap-1.5 items-end max-w-sm">
          {hud.killfeed.map(k => (
            <div
              key={k.id}
              className="flex items-center gap-2 px-3 py-1 bg-neutral-900/80 border border-neutral-700/50 rounded-md backdrop-blur-sm text-xs font-bold shadow-md animate-fade-in"
            >
              <span className={k.killerTeam === 'CT' ? 'text-sky-400' : 'text-amber-400'}>
                {k.killer}
              </span>
              <span className="text-neutral-400 px-1 py-0.5 bg-neutral-800 rounded text-[10px] uppercase">
                {k.weapon}
              </span>
              {k.headshot && (
                <Skull className="w-3.5 h-3.5 text-red-500 inline-block drop-shadow-[0_0_4px_red]" />
              )}
              <span className={k.victimTeam === 'CT' ? 'text-sky-400' : 'text-amber-400'}>
                {k.victim}
              </span>
            </div>
          ))}
        </div>

        {/* --- INTERACTION PROMPT & PROGRESS BAR --- */}
        {hud.interactPrompt && (
          <div className="absolute bottom-36 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 bg-neutral-900/90 border border-neutral-700 px-6 py-3 rounded-xl backdrop-blur-md shadow-2xl">
            <div className="text-sm font-bold text-amber-400 tracking-wider flex items-center gap-2">
              <Crosshair className="w-4 h-4 animate-spin text-amber-400" />
              {hud.interactPrompt}
            </div>
            {hud.interactProgress > 0 && (
              <div className="w-48 h-2 bg-neutral-800 rounded-full overflow-hidden border border-neutral-700">
                <div
                  className="h-full bg-gradient-to-r from-amber-500 to-emerald-400 transition-all duration-75"
                  style={{ width: `${hud.interactProgress * 100}%` }}
                />
              </div>
            )}
          </div>
        )}

        {/* --- BOTTOM HUD: HEALTH, ARMOR, AMMO --- */}
        <div className="absolute bottom-6 left-6 right-6 flex items-end justify-between">
          {/* Health & Armor Panels (Bottom Left) */}
          <div className="flex items-center gap-3">
            {/* Health */}
            <div className="flex items-center gap-3 px-5 py-3 bg-neutral-900/85 border border-neutral-700/60 rounded-xl backdrop-blur-md shadow-2xl">
              <div className="text-emerald-400 font-bold text-xs tracking-wider flex flex-col">
                <span className="text-neutral-400 text-[10px]">+ ЗДОРОВЬЕ</span>
                <span
                  className={`text-4xl font-black font-['Chakra_Petch'] leading-none ${
                    hud.hp <= 25 ? 'text-red-500 animate-pulse' : 'text-emerald-400'
                  }`}
                >
                  {hud.hp}
                </span>
              </div>
              <div className="w-24 h-2 bg-neutral-800 rounded-full overflow-hidden">
                <div
                  className={`h-full transition-all duration-150 ${
                    hud.hp <= 25 ? 'bg-red-500' : 'bg-emerald-400'
                  }`}
                  style={{ width: `${Math.max(0, hud.hp)}%` }}
                />
              </div>
            </div>

            {/* Armor */}
            <div className="flex items-center gap-3 px-4 py-3 bg-neutral-900/85 border border-neutral-700/60 rounded-xl backdrop-blur-md shadow-2xl">
              <Shield className="w-5 h-5 text-sky-400" />
              <div className="flex flex-col">
                <span className="text-neutral-400 text-[10px] font-bold">🛡 БРОНЯ</span>
                <span className="text-3xl font-black font-['Chakra_Petch'] text-sky-400 leading-none">
                  {hud.armor}
                </span>
              </div>
            </div>
          </div>

          {/* Weapon Silhouette & Ammo (Bottom Right) */}
          <div className="flex items-center gap-4 px-6 py-3 bg-neutral-900/85 border border-neutral-700/60 rounded-xl backdrop-blur-md shadow-2xl text-right">
            <div className="flex flex-col items-end">
              <span className="text-xs font-bold tracking-widest text-neutral-400 uppercase">
                {hud.weaponName} • {hud.isAiming ? 'ADS ZOOM' : 'AUTO'}
              </span>
              <div className="flex items-baseline gap-1 text-amber-400 font-black font-['Chakra_Petch']">
                <span className="text-4xl leading-none">{hud.ammo}</span>
                <span className="text-xl text-neutral-500">/ {hud.reserveAmmo}</span>
              </div>
              {hud.isReloading && (
                <span className="text-[11px] font-bold text-amber-400 tracking-wider animate-pulse">
                  ПЕРЕЗАРЯДКА...
                </span>
              )}
            </div>
          </div>
        </div>

        {/* --- ROUND WON / GAME OVER BANNER --- */}
        {hud.isGameOver && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/60 backdrop-blur-sm animate-fade-in pointer-events-none">
            <div className="flex flex-col items-center px-12 py-8 bg-neutral-900/95 border-2 border-neutral-700 rounded-2xl shadow-2xl text-center max-w-lg">
              <div
                className={`text-4xl font-black font-['Chakra_Petch'] uppercase tracking-wider mb-2 ${
                  hud.roundWinner === 'CT' ? 'text-sky-400 drop-shadow-[0_0_15px_#38bdf8]' : 'text-amber-400 drop-shadow-[0_0_15px_#fbbf24]'
                }`}
              >
                {hud.roundWinner === 'CT' ? 'ПОБЕДА СПЕЦНАЗА' : 'ПОБЕДА ТЕРРОРИСТОВ'}
              </div>
              <div className="text-base text-neutral-300 font-medium mb-4">
                {hud.winReason}
              </div>
              <div className="text-xs text-neutral-500 uppercase tracking-widest">
                Следующий раунд начнется через несколько секунд...
              </div>
            </div>
          </div>
        )}

        {/* --- SCOREBOARD OVERLAY (TAB KEY) --- */}
        {showScoreboard && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/75 backdrop-blur-md pointer-events-none">
            <div className="w-[720px] bg-neutral-900/95 border border-neutral-700/80 rounded-xl overflow-hidden shadow-2xl p-6">
              <div className="flex justify-between items-center border-b border-neutral-800 pb-3 mb-4">
                <div>
                  <h2 className="text-2xl font-black tracking-wider text-white">COUNTER-STRIKE 2 • ТАБЛИЦА СЧЕТА</h2>
                  <p className="text-xs text-neutral-400">{hud.mapName} | Режим: {hud.gameMode.toUpperCase()}</p>
                </div>
                <div className="text-right">
                  <span className="text-sm font-bold text-sky-400">CT: {hud.scoreCT}</span>
                  <span className="text-neutral-500 mx-2">vs</span>
                  <span className="text-sm font-bold text-amber-400">T: {hud.scoreT}</span>
                </div>
              </div>

              {/* Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead>
                    <tr className="text-xs font-bold text-neutral-400 border-b border-neutral-800">
                      <th className="pb-2">КОМАНДА / ИМЯ</th>
                      <th className="pb-2 text-center">СТАТУС</th>
                      <th className="pb-2 text-center">УБИЙСТВА</th>
                      <th className="pb-2 text-center">СМЕРТИ</th>
                      <th className="pb-2 text-center">ОЧКИ</th>
                      <th className="pb-2 text-right">ПИНГ</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-800/60 font-semibold">
                    {hud.scoreboard.map(p => (
                      <tr
                        key={p.id}
                        className={p.isPlayer ? 'bg-sky-500/10 text-white' : 'hover:bg-white/5'}
                      >
                        <td className="py-2.5 flex items-center gap-2">
                          <span
                            className={`w-2 h-2 rounded-full ${
                              p.team === 'CT' ? 'bg-sky-400' : 'bg-amber-400'
                            }`}
                          />
                          <span className={p.team === 'CT' ? 'text-sky-300' : 'text-amber-300'}>
                            {p.name}
                          </span>
                        </td>
                        <td className="py-2.5 text-center">
                          <span
                            className={`px-2 py-0.5 rounded text-[11px] ${
                              p.isAlive
                                ? 'bg-emerald-500/20 text-emerald-400'
                                : 'bg-red-500/20 text-red-400'
                            }`}
                          >
                            {p.isAlive ? 'ЖИВ' : 'ПОГИБ'}
                          </span>
                        </td>
                        <td className="py-2.5 text-center">{p.kills}</td>
                        <td className="py-2.5 text-center">{p.deaths}</td>
                        <td className="py-2.5 text-center font-bold text-amber-400">{p.score}</td>
                        <td className="py-2.5 text-right text-xs text-neutral-400">{p.ping}ms</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* --- START / PAUSE / SETTINGS OVERLAY --- */}
      {(!isGameStarted || showSettings) && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md pointer-events-auto p-6">
          <div className="max-w-2xl w-full bg-neutral-900 border border-neutral-700/80 rounded-2xl shadow-2xl p-8 flex flex-col gap-6">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-neutral-800 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <Gamepad2 className="w-8 h-8 text-amber-500" />
                  <h1 className="text-3xl font-black font-['Chakra_Petch'] tracking-wider text-white">
                    COUNTER-STRIKE 2 <span className="text-amber-500 text-xl font-bold">3D FPS</span>
                  </h1>
                </div>
                <p className="text-sm text-neutral-400 mt-1">
                  Tactical FPS на Three.js • PointerLock • Боты с ИИ • 3 Карты • Оружие с отдачей
                </p>
              </div>

              {/* Mute button */}
              <button
                onClick={toggleMute}
                className="p-2.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 rounded-lg transition-colors"
                title="Звук Вкл/Выкл"
              >
                {isMuted ? <VolumeX className="w-5 h-5 text-red-400" /> : <Volume2 className="w-5 h-5 text-emerald-400" />}
              </button>
            </div>

            {/* Selection Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Maps */}
              <div className="flex flex-col gap-2">
                <label className="text-xs font-bold text-neutral-400 uppercase tracking-wider">
                  ВЫБОР КАРТЫ:
                </label>
                <div className="flex flex-col gap-2">
                  {[
                    { id: 'dust2', name: 'de_dust2 (Песок/Mid/A/B)', badge: 'Classic' },
                    { id: 'house', name: 'cs_mansion (Дом 2 этажа)', badge: 'CQB' },
                    { id: 'trenches', name: 'de_trenches (Лес & Окопы)', badge: 'Atmospheric' },
                  ].map(m => (
                    <button
                      key={m.id}
                      onClick={() => handleMapChange(m.id as 'dust2' | 'house' | 'trenches')}
                      className={`px-3 py-2.5 rounded-lg text-left text-xs font-bold border transition-all ${
                        selectedMap === m.id
                          ? 'bg-amber-500/20 border-amber-500 text-amber-300 shadow-md'
                          : 'bg-neutral-800/60 border-neutral-700/60 text-neutral-300 hover:bg-neutral-800'
                      }`}
                    >
                      <div className="flex justify-between items-center">
                        <span>{m.name}</span>
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-neutral-700 text-neutral-300 font-normal">
                          {m.badge}
                        </span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Game Modes */}
              <div className="flex flex-col gap-2">
                <label className="text-xs font-bold text-neutral-400 uppercase tracking-wider">
                  РЕЖИМ ИГРЫ:
                </label>
                <div className="flex flex-col gap-2">
                  <button
                    onClick={() => handleModeChange('defusal')}
                    className={`px-3 py-2.5 rounded-lg text-left text-xs font-bold border transition-all ${
                      gameMode === 'defusal'
                        ? 'bg-amber-500/20 border-amber-500 text-amber-300 shadow-md'
                        : 'bg-neutral-800/60 border-neutral-700/60 text-neutral-300 hover:bg-neutral-800'
                    }`}
                  >
                    <div>Закладка бомбы (Defusal)</div>
                    <div className="text-[11px] font-normal text-neutral-400 mt-0.5">
                      Пленты A и B, C4 таймер, разминирование [E]
                    </div>
                  </button>

                  <button
                    onClick={() => handleModeChange('tdm')}
                    className={`px-3 py-2.5 rounded-lg text-left text-xs font-bold border transition-all ${
                      gameMode === 'tdm'
                        ? 'bg-amber-500/20 border-amber-500 text-amber-300 shadow-md'
                        : 'bg-neutral-800/60 border-neutral-700/60 text-neutral-300 hover:bg-neutral-800'
                    }`}
                  >
                    <div>Командный бой (Deathmatch)</div>
                    <div className="text-[11px] font-normal text-neutral-400 mt-0.5">
                      Сражение до уничтожения команды или таймера
                    </div>
                  </button>
                </div>
              </div>

              {/* Team Selection */}
              <div className="flex flex-col gap-2">
                <label className="text-xs font-bold text-neutral-400 uppercase tracking-wider">
                  ВАША КОМАНДА:
                </label>
                <div className="flex flex-col gap-2">
                  <button
                    onClick={() => handleTeamChange('CT')}
                    className={`px-3 py-2.5 rounded-lg text-left text-xs font-bold border transition-all ${
                      team === 'CT'
                        ? 'bg-sky-500/20 border-sky-500 text-sky-300 shadow-md'
                        : 'bg-neutral-800/60 border-neutral-700/60 text-neutral-300 hover:bg-neutral-800'
                    }`}
                  >
                    <div className="text-sky-400">Спецназ (Counter-Terrorists)</div>
                    <div className="text-[11px] font-normal text-neutral-400 mt-0.5">
                      Защита плентов & Разминирование
                    </div>
                  </button>

                  <button
                    onClick={() => handleTeamChange('T')}
                    className={`px-3 py-2.5 rounded-lg text-left text-xs font-bold border transition-all ${
                      team === 'T'
                        ? 'bg-amber-500/20 border-amber-500 text-amber-300 shadow-md'
                        : 'bg-neutral-800/60 border-neutral-700/60 text-neutral-300 hover:bg-neutral-800'
                    }`}
                  >
                    <div className="text-amber-400">Террористы (Terrorists)</div>
                    <div className="text-[11px] font-normal text-neutral-400 mt-0.5">
                      Прорыв к точке A/B & Закладка C4
                    </div>
                  </button>
                </div>
              </div>
            </div>

            {/* Controls Guide */}
            <div className="bg-neutral-950/80 border border-neutral-800 rounded-xl p-4 text-xs text-neutral-300 grid grid-cols-2 md:grid-cols-4 gap-3">
              <div><b className="text-white">WASD:</b> Перемещение</div>
              <div><b className="text-white">Space:</b> Прыжок</div>
              <div><b className="text-white">Shift:</b> Спринт / Бег</div>
              <div><b className="text-white">ЛКМ:</b> Стрельба</div>
              <div><b className="text-white">ПКМ:</b> Прицеливание (ADS)</div>
              <div><b className="text-white">R:</b> Перезарядка</div>
              <div><b className="text-white">E:</b> Заложить / Разминировать</div>
              <div><b className="text-white">1 / 2:</b> Автомат / Пистолет</div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-3 pt-2">
              <button
                onClick={handleStartGame}
                className="flex-1 py-3.5 px-6 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-black font-black font-['Chakra_Petch'] text-lg tracking-wider shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-[0.98]"
              >
                <Play className="w-5 h-5 fill-current" />
                В БОЙ (START GAME)
              </button>

              <button
                onClick={handleDownloadStandalone}
                className="py-3.5 px-5 rounded-xl bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-white font-bold text-sm flex items-center justify-center gap-2 cursor-pointer transition-colors"
                title="Скачать полный код в одном HTML-файле"
              >
                <Download className="w-4 h-4 text-amber-400" />
                Скачать Single-file HTML
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
